# PaydFinance

Premium dark fintech starter for an AI-powered financial assistant. Built with React + Vite + TypeScript, a separate Express API, Supabase, an AI provider abstraction, and an explicitly unconfigured Rialo adapter.

## What is included

- 12 product areas: AI Mentor, portfolio, market intelligence, analyzer, personal finance, automation, risk, news, transactions, watchlist/alerts, account/security, reports.
- Responsive dashboard shell with navigation and mobile layout.
- Express API with health, AI chat, market, portfolio, alerts, automation and Rialo status routes.
- OpenAI provider adapter plus a provider-switching interface.
- Supabase browser client and SQL schema with Row Level Security policies.
- Rialo adapter that reports unavailable until official network details, SDK and contract interfaces are configured. It does not invent RPCs, chain IDs, SDK methods or transaction success.
- Setup and deployment instructions.

## Requirements

- Node.js 20+
- npm 10+
- A Supabase project
- An OpenAI API key for live AI responses

## Local setup

1. Copy `client/.env.example` to `client/.env` and fill in the Supabase URL, anon key and API URL.
2. Copy `server/.env.example` to `server/.env` and fill in the backend Supabase values and OpenAI key.
3. Run `npm install` from the repository root.
4. Run `npm run dev`.
5. Open http://localhost:5173. API runs at http://localhost:4000.

The service role key and AI keys must remain server-side. Do not prefix secrets with `VITE_`.

## Supabase

Run `supabase/schema.sql` in the Supabase SQL editor. Enable email authentication in Supabase Auth. The schema enables RLS and scopes user-owned rows to `auth.uid()`.

The starter uses Supabase Auth in the browser. The backend should verify Supabase JWTs before exposing user-specific production data. The included demo endpoints return clearly labelled sample data until real providers and authorization are configured.

## Rialo integration (see also the in-app Rialo Docs page)

Developers: start with [docs/RIALO_INTEGRATION.md](docs/RIALO_INTEGRATION.md), which links the official Rialo docs and lists the go-live checklist. The same guide is in the app under Developer Docs.

`server/src/integrations/rialo/RialoAdapter.ts` is a **read-only** client over the Rialo node's HTTP JSON-RPC interface. It calls `getHealth`, `getBalance` and `getAccountInfo`, the method names used by the published `rialo-cdk` client (docs.rs/crate/rialo-cdk). Those names were taken from an older published version, so confirm them against the current docs.

Balances are returned in kelvin and RLO (1 RLO = 1,000,000,000 kelvin). The top bar has a watch-only wallet connection: users paste a public address, stored in the browser only. No browser-wallet standard for Rialo is verified yet, so signing wallets are not supported.

Endpoints: `GET /api/rialo/status` (also `/api/health/rialo`) and `GET /api/rialo/account/:address`. `POST /api/rialo/transactions` always returns 501.

Enable it by setting, from official Rialo documentation:

```
RIALO_ENABLED=true
RIALO_RPC_URL=<official RPC endpoint>
RIALO_NETWORK=<devnet|testnet|mainnet|localnet>
RIALO_CHAIN_ID=<official chain ID, if applicable>
```

Nothing is defaulted: no RPC URL or chain ID is assumed. Balances are returned as raw kelvin without unit conversion until the conversion is verified. The server never holds keys and never submits transactions; signing must happen in a user-controlled wallet. Still to do: verify the JSON-RPC version string and response shapes against a live node, add integration tests, and build wallet-signed writes.

## Deploy

See `docs/DEPLOY_VERCEL.md` (one Vercel project serves the site and the API).

## Connected wallet

The top-bar wallet menu supports two modes. A **signing wallet** is any adapter registered in `client/src/lib/walletAdapter.ts` (none yet; the menu lists "Rialo Wallet, available when Rialo launches"). A **watch-only wallet** is a public address saved in the browser. Watch-only wallets show balances but can never approve transactions, and the approval dialog says so. You can keep up to 8 wallets, switch between them, rename and remove them, and the connection syncs across tabs. Only public addresses, labels and the mode are stored. The menu lists what the site can and cannot do. Any page can open it with `openWalletMenu()`.

## Swap, sell, send and bridge (go-live ready)

The Swap, Sell, Send and Bridge pages validate input, then open a review dialog whose final step calls `adapter.approveAndSend(intent)` (`client/src/lib/walletAdapter.ts`). The connected wallet shows its own permission prompt and signs. PaydFinance never holds keys and the server never signs (`POST /api/trade/*` returns 501).

Each page shows a "Waiting for Rialo" checklist and turns on by itself when every item is in place. `GET /api/rialo/readiness` reports, per feature, what is still missing:

| Feature | Needs |
|---|---|
| Send | `RIALO_ENABLED=true`, `RIALO_RPC_URL`, a signing wallet adapter |
| Swap and Sell | the above, plus a swap venue registered in `server/src/integrations/rialo/venues.ts` and `RIALO_SWAP_ENABLED=true` |
| Bridge | the above, plus a bridge provider registered in `venues.ts` and `RIALO_BRIDGE_ENABLED=true` |

To go live when Rialo launches:
1. Set the `RIALO_*` variables from the official docs.
2. Copy `client/src/lib/rialoWalletAdapter.template.ts`, fill it in from the official wallet SDK, and add it to `adapters`.
3. Implement `SwapVenue` and `BridgeProvider` in `venues.ts` (quote only) and register them. `GET /api/trade/quote`, `/api/trade/bridge/routes` and `/api/trade/bridge/quote` then use them automatically.
4. Test on devnet before mainnet.

Until a venue is registered, swap and sell quotes are indicative CoinGecko reference prices with no fees or slippage. Nothing in this repo guesses Rialo wallet, DEX or bridge calls.

Economic Data (`/economy`) shows global crypto market context (CoinGecko) and US indicators from FRED when `FRED_API_KEY` is set.

## AI provider switching

`server/src/ai/AIProvider.ts` defines the interface. `server/src/ai/providers/OpenAIProvider.ts` implements OpenAI. Add another provider by implementing the same interface and registering it in `server/src/ai/providerFactory.ts`. All provider credentials remain in backend environment variables.

AI output is informational and can be wrong. The app does not provide personalized investment advice or execute trades.

## Deployment

### Frontend on Vercel

1. Push the repository to GitHub.
2. Import the repository into Vercel.
3. Set the project root to `client`.
4. Build command: `npm run build`.
5. Output directory: `dist`.
6. Add `VITE_API_BASE_URL` pointing to your deployed API, plus `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
7. Deploy.

If deploying the monorepo, ensure Vercel has access to the root lockfile/workspace dependencies. Alternatively, deploy the `client` as its own project after installing dependencies from the monorepo root.

### Backend

Deploy `server` to Railway, Render or another Node host. Set the start command to `npm start` and configure all backend variables from `.env.example`. Set `CLIENT_ORIGIN` to your Vercel domain. Add a health check at `/api/health`.

### Production checklist

- Add Supabase JWT verification middleware to every private backend route.
- Configure strict CORS for production domains.
- Add request rate limits and abuse monitoring.
- Add provider-backed market data and news integrations.
- Replace sample data with validated provider responses.
- Add audit logging, error monitoring, backups and tests.
- Perform a security review before handling real funds.
