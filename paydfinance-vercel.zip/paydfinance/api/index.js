// Vercel serverless entry. Runs the compiled Express app from server/dist (built by `npm run build`).
let appPromise;
module.exports = async (req, res) => {
  appPromise ??= import('../server/dist/app.js').then(m => m.default);
  const app = await appPromise;
  return app(req, res);
};
