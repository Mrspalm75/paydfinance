import { useState } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import Dashboard from './pages/Dashboard';
import Developers from './pages/Developers';
import Trade from './pages/Trade';
import Economy from './pages/Economy';
import ModulePage from './pages/ModulePage';

export default function App() {
  const [menuOpen,setMenuOpen] = useState(false);
  return <div className="app-shell">
    <Sidebar open={menuOpen} onClose={()=>setMenuOpen(false)}/>
    <main className="main-shell"><Topbar onMenu={()=>setMenuOpen(true)}/>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace/>}/>
        <Route path="/dashboard" element={<Dashboard/>}/>
        <Route path="/ai-mentor" element={<ModulePage id="ai-mentor"/>}/>
        <Route path="/markets" element={<ModulePage id="markets"/>}/>
        <Route path="/analyzer" element={<ModulePage id="analyzer"/>}/>
        <Route path="/portfolio" element={<ModulePage id="portfolio"/>}/>
        <Route path="/finance" element={<ModulePage id="finance"/>}/>
        <Route path="/automation" element={<ModulePage id="automation"/>}/>
        <Route path="/risk" element={<ModulePage id="risk"/>}/>
        <Route path="/news" element={<ModulePage id="news"/>}/>
        <Route path="/transactions" element={<ModulePage id="transactions"/>}/>
        <Route path="/watchlist" element={<ModulePage id="watchlist"/>}/>
        <Route path="/reports" element={<ModulePage id="reports"/>}/>
        <Route path="/notifications" element={<ModulePage id="notifications"/>}/>
        <Route path="/swap" element={<Trade tab="swap"/>}/>
        <Route path="/sell" element={<Trade tab="sell"/>}/>
        <Route path="/send" element={<Trade tab="send"/>}/>
        <Route path="/bridge" element={<Trade tab="bridge"/>}/>
        <Route path="/economy" element={<Economy/>}/>
        <Route path="/developers" element={<Developers/>}/>
        <Route path="/settings" element={<ModulePage id="settings"/>}/>
        <Route path="*" element={<Navigate to="/dashboard" replace/>}/>
      </Routes>
      <footer className="app-footer"><span>© 2026 PaydFinance</span><span>Financial intelligence, with clarity.</span></footer>
    </main>
  </div>;
}
