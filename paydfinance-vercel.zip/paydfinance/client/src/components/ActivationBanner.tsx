import { useReadiness } from '../lib/readiness';
import type { TxIntent } from '../lib/walletAdapter';

export default function ActivationBanner({ kind }: { kind: TxIntent['kind'] }) {
  const r = useReadiness(kind);
  if (r.ready) return <div className="doc-note safe">Live on Rialo. Your wallet will ask for permission before anything is sent.</div>;
  return <div className="doc-note warn"><strong>Waiting for Rialo.</strong> This page switches on by itself once these are in place:
    <ul className="doc-list" style={{ marginTop: 6 }}>{r.pending.map(p => <li key={p}>{p}</li>)}</ul></div>;
}
