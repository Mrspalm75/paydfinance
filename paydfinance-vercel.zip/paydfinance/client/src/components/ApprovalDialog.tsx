import { useState } from 'react';
import { ShieldCheck, X } from 'lucide-react';
import { adapterFor, type TxIntent } from '../lib/walletAdapter';
import { useReadiness } from '../lib/readiness';
import { useWallet } from '../lib/wallet';

export default function ApprovalDialog({ intent, lines, onClose }: { intent: TxIntent; lines: [string, string][]; onClose: () => void }) {
  const { address, canSign, mode } = useWallet();
  const readiness = useReadiness(intent.kind);
  const adapter = readiness.ready && canSign ? adapterFor(intent.kind) : undefined;
  const [ack, setAck] = useState(false); const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [sig, setSig] = useState('');
  async function approve() {
    if (!adapter) return;
    setBusy(true); setError('');
    try { setSig((await adapter.approveAndSend(intent)).signature); }
    catch (e) { setError(e instanceof Error ? e.message : 'The wallet declined or the transaction failed.'); }
    finally { setBusy(false); }
  }
  return <div className="modal-scrim" role="dialog" aria-modal="true" aria-label="Review and approve">
    <div className="modal-card">
      <div className="wallet-pop-head"><strong>Review and approve</strong><button className="icon-button" onClick={onClose} aria-label="Close"><X size={16}/></button></div>
      <div className="modal-lines">{[['From wallet', address || 'Not connected'], ...lines].map(([k, v]) => <div className="wallet-row" key={k}><span>{k}</span><b style={{ wordBreak: 'break-all', textAlign: 'right' }}>{v}</b></div>)}</div>
      {sig ? <div className="doc-note safe">Submitted. Signature: <code>{sig}</code></div> : <>
        {!adapter && readiness.ready && mode === 'watch' && <div className="doc-note warn">This wallet is watch-only and cannot approve transactions. Connect a signing wallet from the top bar. Nothing was sent.</div>}
        {!adapter && !(readiness.ready && mode === 'watch') && <div className="doc-note warn">This action is not live yet. Waiting for: {readiness.pending.join('; ')}. Your details above are only a review, and nothing was sent.</div>}
        {adapter && <label className="doc-p" style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}><input type="checkbox" checked={ack} onChange={e => setAck(e.target.checked)}/> I checked the address, amount and network. Transactions cannot be reversed.</label>}
        {error && <div className="error-box">{error}</div>}
        <button className="primary-button" disabled={!adapter || !ack || busy} onClick={approve}><ShieldCheck size={15}/> {busy ? `Waiting for ${adapter?.name}…` : adapter ? `Approve in ${adapter.name}` : 'Approve in wallet (not available yet)'}</button>
      </>}
    </div>
  </div>;
}
