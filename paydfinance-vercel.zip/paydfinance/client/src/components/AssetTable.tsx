import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useMarkets, usd, pct, compact } from '../lib/market';
export default function AssetTable() {
  const { data, isLoading, isError } = useMarkets();
  return <div className="panel asset-panel">
    <div className="panel-heading"><div><h3>Market watch</h3><p>{data ? `Live prices · ${data.source} · updated ${new Date(data.fetchedAt).toLocaleTimeString()}` : isError ? 'Live prices unavailable' : 'Loading live prices…'}</p></div><Link className="text-action" to="/markets">View markets ↗</Link></div>
    <div className="table-scroll"><table><thead><tr><th>ASSET</th><th>PRICE</th><th>24H CHANGE</th><th>MARKET CAP</th><th>24H VOLUME</th></tr></thead>
      <tbody>{isLoading && <tr><td colSpan={5}>Loading…</td></tr>}{isError && <tr><td colSpan={5}>Could not load market data. The API or provider may be down.</td></tr>}
      {data?.assets.map(a => { const up = (a.change24h ?? 0) >= 0; return <tr key={a.symbol}><td><div className="asset-name"><div className={`coin coin-${a.symbol.toLowerCase()}`}>{a.symbol.slice(0,1)}</div><div><strong>{a.name}</strong><small>{a.symbol}</small></div></div></td><td className="price-cell">{usd(a.price)}</td><td><span className={up ? 'positive' : 'negative'}>{up ? <ArrowUpRight size={14}/> : <ArrowDownRight size={14}/>} {pct(a.change24h)}</span></td><td>{compact(a.marketCap)}</td><td>{compact(a.volume24h)}</td></tr>; })}</tbody>
    </table></div>
  </div>;
}
