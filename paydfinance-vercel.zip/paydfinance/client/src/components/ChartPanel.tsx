import { useState } from 'react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { useChart, usd, pct } from '../lib/market';
const ranges = [{ d: 1, l: '24h' }, { d: 7, l: '7 days' }, { d: 30, l: '30 days' }, { d: 90, l: '90 days' }];
export default function ChartPanel() {
  const [days, setDays] = useState(7);
  const { data, isLoading, isError } = useChart('bitcoin', days);
  const pts = data?.points ?? [];
  const change = pts.length > 1 ? ((pts[pts.length - 1].price - pts[0].price) / pts[0].price) * 100 : null;
  const fmt = (t: number) => days === 1 ? new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : new Date(t).toLocaleDateString([], { month: 'short', day: 'numeric' });
  return <div className="panel chart-panel">
    <div className="panel-heading"><div><h3>Bitcoin price</h3><p>{data ? `Live market data · ${data.source} · USD` : isError ? 'Live data unavailable' : 'Loading…'}</p></div>
      <select className="period-select" value={days} onChange={e => setDays(Number(e.target.value))} aria-label="Range">{ranges.map(r => <option key={r.d} value={r.d}>{r.l}</option>)}</select></div>
    <div className="chart-legend"><span className="legend-dot"/> BTC / USD {change != null && <span className={change >= 0 ? 'chart-positive' : 'negative'}>{pct(change)}</span>}</div>
    <div className="chart-wrap">{isError ? <p style={{color:'#818ba0',fontSize:12}}>Could not load the chart.</p> : isLoading ? <p style={{color:'#818ba0',fontSize:12}}>Loading chart…</p> :
      <ResponsiveContainer width="100%" height="100%"><AreaChart data={pts} margin={{ top: 10, right: 5, left: 0, bottom: 0 }}>
        <defs><linearGradient id="portfolioFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#8b7cff" stopOpacity={0.28}/><stop offset="100%" stopColor="#8b7cff" stopOpacity={0}/></linearGradient></defs>
        <CartesianGrid stroke="#222a3a" strokeDasharray="3 5" vertical={false}/>
        <XAxis dataKey="t" tickFormatter={fmt} axisLine={false} tickLine={false} tick={{ fill: '#778198', fontSize: 11 }} minTickGap={40} dy={10}/>
        <YAxis domain={['auto', 'auto']} width={62} axisLine={false} tickLine={false} tick={{ fill: '#778198', fontSize: 11 }} tickFormatter={v => `$${Math.round(v).toLocaleString()}`}/>
        <Tooltip labelFormatter={t => new Date(t as number).toLocaleString()} formatter={(v: number) => [usd(v), 'BTC']} contentStyle={{ background: '#151c2b', border: '1px solid #2a3448', borderRadius: 10, color: '#fff' }}/>
        <Area type="monotone" dataKey="price" stroke="#9b8cff" strokeWidth={2.5} fill="url(#portfolioFill)" dot={false}/>
      </AreaChart></ResponsiveContainer>}</div>
  </div>;
}
