import { useCallback, useRef, useState } from 'react';
import { ArrowUpRight, ImagePlus, X } from 'lucide-react';
import { api } from '../lib/api';

const MAX_BYTES = 10 * 1024 * 1024;
// Downscale in the browser so uploads stay small and fast.
async function toDataUrl(file: File): Promise<string> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(bitmap.width * scale); canvas.height = Math.round(bitmap.height * scale);
  canvas.getContext('2d')!.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL('image/jpeg', 0.85);
}

export default function ChartUpload() {
  const input = useRef<HTMLInputElement>(null);
  const [image, setImage] = useState(''); const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState(''); const [error, setError] = useState(''); const [busy, setBusy] = useState(false); const [drag, setDrag] = useState(false);

  const load = useCallback(async (file?: File | null) => {
    if (!file) return; setError(''); setAnswer('');
    if (!/^image\/(png|jpeg|webp)$/.test(file.type)) return setError('Upload a PNG, JPEG or WebP image of a chart.');
    if (file.size > MAX_BYTES) return setError('That image is over 10 MB. Use a smaller screenshot.');
    try { setImage(await toDataUrl(file)); } catch { setError('Could not read that image.'); }
  }, []);

  async function analyze() {
    setBusy(true); setError(''); setAnswer('');
    try { const r = await api<{ answer: string }>('/ai/analyze-chart', { method: 'POST', body: JSON.stringify({ image, question: question || undefined }) }); setAnswer(r.answer); }
    catch (e) { setError(e instanceof Error ? e.message : 'Unable to reach the AI service.'); }
    finally { setBusy(false); }
  }

  return <div className="panel ai-workspace" onPaste={e => load(Array.from(e.clipboardData.files)[0])}>
    <div className="panel-heading"><div><h3>Upload a chart</h3><p>Add a screenshot of any price chart and ask what it shows.</p></div><span className="ai-chip"><ImagePlus size={13}/> CHART READER</span></div>
    {!image
      ? <button type="button" className="suggestion" style={{ width: '100%', padding: '34px 16px', marginBottom: 12, borderStyle: 'dashed', borderColor: drag ? '#a797ff' : undefined }}
          onClick={() => input.current?.click()} onDragOver={e => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)}
          onDrop={e => { e.preventDefault(); setDrag(false); load(e.dataTransfer.files[0]); }}>
          Drop a chart image here, paste it, or click to choose a file (PNG, JPEG, WebP)</button>
      : <div style={{ position: 'relative', marginBottom: 12 }}><img src={image} alt="Uploaded chart" style={{ width: '100%', maxHeight: 380, objectFit: 'contain', borderRadius: 8, background: '#0b101b' }}/>
          <button className="icon-button" aria-label="Remove image" style={{ position: 'absolute', top: 8, right: 8, background: '#0b101bcc', borderRadius: 6 }} onClick={() => { setImage(''); setAnswer(''); }}><X size={16}/></button></div>}
    <input ref={input} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={e => { load(e.target.files?.[0]); e.target.value = ''; }}/>
    <div className="suggestion-row">{['What is the overall trend?', 'Where are support and resistance?', 'Explain the indicators shown'].map(s => <button key={s} className="suggestion" onClick={() => setQuestion(s)}>{s}</button>)}</div>
    <textarea value={question} onChange={e => setQuestion(e.target.value)} placeholder="Optional: ask a specific question about this chart" rows={2}/>
    <div className="ai-submit-row"><small>Educational reading of a screenshot, not live data or investment advice.</small><button className="primary-button" disabled={busy || !image} onClick={analyze}>{busy ? 'Reading chart…' : 'Analyse chart'} <ArrowUpRight size={15}/></button></div>
    {error && <div className="error-box">{error}</div>}{answer && <div className="answer-box"><strong>Payd AI</strong><p style={{ whiteSpace: 'pre-wrap' }}>{answer}</p></div>}
  </div>;
}
