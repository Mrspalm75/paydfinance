import { useRialoStatus, rialoLabel } from '../lib/useRialoStatus';
import { NavLink } from 'react-router-dom';
import {
  Activity, BarChart3, Bot, BriefcaseBusiness, ChartNoAxesCombined, CircleDollarSign,
  FileText, Gauge, LayoutDashboard, ListChecks, Newspaper, Settings, ShieldAlert,
  Wallet, Bell, ArrowLeftRight, X, BookOpen, Repeat, Send, Landmark, Globe
} from 'lucide-react';

const groups = [
  { label: 'WORKSPACE', items: [
    ['Dashboard', '/dashboard', LayoutDashboard], ['AI Mentor', '/ai-mentor', Bot],
    ['Markets', '/markets', BarChart3], ['Market Analyzer', '/analyzer', ChartNoAxesCombined],
    ['Portfolio', '/portfolio', Wallet], ['Personal Finance', '/finance', CircleDollarSign],
    ['Economic Data', '/economy', Landmark],
  ]},
  { label: 'TRADE', items: [
    ['Swap', '/swap', Repeat], ['Sell', '/sell', CircleDollarSign], ['Send', '/send', Send], ['Bridge', '/bridge', Globe],
  ]},
  { label: 'MANAGEMENT', items: [
    ['Automation', '/automation', Activity], ['Risk Center', '/risk', ShieldAlert],
    ['News Intelligence', '/news', Newspaper], ['Transactions', '/transactions', ArrowLeftRight],
    ['Watchlist', '/watchlist', ListChecks], ['Reports', '/reports', FileText],
  ]},
  { label: 'ACCOUNT', items: [
    ['Notifications', '/notifications', Bell], ['Settings', '/settings', Settings], ['Rialo Docs', '/developers', BookOpen],
  ]},
] as const;

export default function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const rialo = useRialoStatus(); const label = rialoLabel(rialo.data, rialo.isError);
  return <>
    {open && <button className="mobile-scrim" onClick={onClose} aria-label="Close navigation" />}
    <aside className={`sidebar ${open ? 'sidebar-open' : ''}`}>
      <div className="brand-row">
        <div className="brand-mark"><Gauge size={20}/></div>
        <div><strong>payd<span>finance</span></strong><small>FINANCIAL INTELLIGENCE</small></div>
        <button className="icon-button mobile-close" onClick={onClose}><X size={18}/></button>
      </div>
      <div className="workspace-pill"><span className="status-dot"/> Personal workspace <span className="chevron">⌄</span></div>
      <nav>
        {groups.map(group => <div className="nav-group" key={group.label}>
          <div className="nav-label">{group.label}</div>
          {group.items.map(([label, path, Icon]) => <NavLink key={path} to={path} onClick={onClose} className={({isActive}) => `nav-link ${isActive ? 'active' : ''}`}>
            <Icon size={17}/><span>{label}</span>
            {label === 'AI Mentor' && <span className="nav-new">AI</span>}
          </NavLink>)}
        </div>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="rialo-card">
          <div className="rialo-top"><span className="rialo-orb"/> RIALO CONNECTION</div>
          <strong>{label.title}</strong>
          <small>{rialo.data?.configured ? rialo.data.message : 'Everything in PaydFinance is built for Rialo. Live access begins when mainnet is public.'}</small>
          <span className={label.tone}>● {label.dot}</span>
        </div>
        <div className="user-mini"><div className="avatar">P</div><div><strong>Personal account</strong><small>Free workspace</small></div><span className="more">•••</span></div>
      </div>
    </aside>
  </>;
}
