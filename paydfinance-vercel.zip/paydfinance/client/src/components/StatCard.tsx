import type { ReactNode } from 'react';
export default function StatCard({ label, value, change, icon, tone = 'violet' }: {
  label: string; value: string; change?: string; icon: ReactNode; tone?: string;
}) {
  return <div className="stat-card">
    <div className="stat-top"><span>{label}</span><div className={`stat-icon ${tone}`}>{icon}</div></div>
    <div className="stat-value">{value}</div>
    {change && <div className="stat-change"><span>{change}</span><small> vs. previous period</small></div>}
  </div>;
}
