import { Bell, Menu, Search, Sparkles } from 'lucide-react';
import WalletButton from './WalletButton';
import { useLocation } from 'react-router-dom';

const titles: Record<string, string> = {
  '/dashboard': 'Overview', '/ai-mentor': 'AI Financial Mentor', '/markets': 'Market Intelligence',
  '/analyzer': 'Market Analyzer', '/portfolio': 'Portfolio Manager', '/finance': 'Personal Finance',
  '/automation': 'Smart Automation', '/risk': 'Risk Center', '/news': 'News Intelligence',
  '/transactions': 'Transactions', '/watchlist': 'Watchlist & Alerts', '/reports': 'Reports',
  '/notifications': 'Notifications', '/settings': 'Settings & Security', '/developers': 'Rialo Docs', '/swap': 'Swap', '/sell': 'Sell', '/send': 'Send', '/bridge': 'Bridge', '/economy': 'Economic Data',
};

export default function Topbar({ onMenu }: { onMenu: () => void }) {
  const location = useLocation();
  return <header className="topbar">
    <button className="icon-button menu-button" onClick={onMenu}><Menu size={20}/></button>
    <div className="breadcrumbs"><span>Workspace</span><b>/</b><strong>{titles[location.pathname] || 'Overview'}</strong></div>
    <div className="top-actions">
      <button className="search-trigger"><Search size={16}/> <span>Search anything</span><kbd>⌘ K</kbd></button>
      <WalletButton/>
      <button className="icon-button notification-button" aria-label="Notifications"><Bell size={18}/><i/></button>
      <div className="avatar top-avatar">P</div>
    </div>
  </header>;
}
