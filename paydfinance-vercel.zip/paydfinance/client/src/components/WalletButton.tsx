import { useEffect, useRef, useState } from 'react';
import { Check, Copy, Eye, RefreshCw, ShieldCheck, Trash2, Wallet, X } from 'lucide-react';
import { adapters } from '../lib/walletAdapter';
import { shortAddress, useRialoAccount, useWallet, WALLET_OPEN_EVENT } from '../lib/wallet';
import { rialoLabel, useRialoStatus } from '../lib/useRialoStatus';

export default function WalletButton() {
  const w = useWallet();
  const [open, setOpen] = useState(false); const [value, setValue] = useState(''); const [label, setLabel] = useState('');
  const [error, setError] = useState(''); const [busy, setBusy] = useState(''); const [copied, setCopied] = useState(false); const [adding, setAdding] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const status = useRialoStatus(); const rl = rialoLabel(status.data, status.isError);
  const account = useRialoAccount(w.address);
  useEffect(() => {
    const close = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false); };
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    const show = () => setOpen(true);
    document.addEventListener('mousedown', close); document.addEventListener('keydown', esc); window.addEventListener(WALLET_OPEN_EVENT, show);
    return () => { document.removeEventListener('mousedown', close); document.removeEventListener('keydown', esc); window.removeEventListener(WALLET_OPEN_EVENT, show); };
  }, []);
  const addWatch = () => { const err = w.connectWatch(value, label); setError(err ?? ''); if (!err) { setValue(''); setLabel(''); setAdding(false); setOpen(false); } };
  const connectWith = async (id: string) => { setBusy(id); setError(''); const err = await w.connectAdapter(id); setBusy(''); if (err) setError(err); else setOpen(false); };
  const copy = async () => { try { await navigator.clipboard.writeText(w.address); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch { /* clipboard blocked */ } };
  const showForm = !w.address || adding;
  const balance = account.data?.balanceRlo != null ? `${account.data.balanceRlo} RLO` : account.isError ? 'Unavailable' : status.data?.reachable ? 'Loading…' : 'Awaiting mainnet';

  return <div className="wallet-wrap" ref={ref}>
    <button className={`wallet-btn ${w.address ? 'connected' : ''}`} onClick={() => setOpen(o => !o)} aria-expanded={open} aria-haspopup="dialog">
      <Wallet size={16}/><span>{w.address ? shortAddress(w.address) : 'Connect wallet'}</span>{w.address && <i className="status-dot"/>}
    </button>
    {open && <div className="wallet-pop" role="dialog" aria-label="Wallet">
      <div className="wallet-pop-head"><strong>{w.address ? 'Wallet' : 'Connect a wallet'}</strong><button className="icon-button" onClick={() => setOpen(false)} aria-label="Close"><X size={16}/></button></div>

      {w.address && <>
        <div className="wallet-badge-row"><span className={`wallet-badge ${w.canSign ? 'sign' : ''}`}>{w.canSign ? <><ShieldCheck size={12}/> {w.label}</> : <><Eye size={12}/> Watch-only</>}</span><small>{w.label}</small></div>
        <div className="wallet-addr"><code>{w.address}</code><button className="icon-button" aria-label="Copy address" onClick={copy}>{copied ? <Check size={15}/> : <Copy size={15}/>}</button></div>
        <div className="wallet-row"><span>Balance</span><b>{balance} <button className="icon-button" style={{ display: 'inline-grid', verticalAlign: 'middle' }} aria-label="Refresh balance" onClick={() => account.refetch()} disabled={!status.data?.reachable}><RefreshCw size={13} className={account.isFetching ? 'spin' : ''}/></button></b></div>
        <div className="wallet-row"><span>Rialo network</span><b>{rl.dot}</b></div>
        <div className="wallet-perms"><strong>Permissions</strong>
          <span>Can: see this public address and its balance.</span>
          <span>{w.canSign ? 'Can: ask your wallet to approve a send, swap, sell or bridge. You confirm each one in the wallet.' : 'Cannot: request approvals. Connect a signing wallet to send, swap, sell or bridge.'}</span>
          <span>Cannot: move funds on its own or see keys.</span></div>
      </>}

      {w.saved.length > 1 && <div className="wallet-list"><strong>Your wallets</strong>
        {w.saved.map(s => <div className={`wallet-item ${s.address === w.address ? 'active' : ''}`} key={s.address}>
          <button onClick={() => { w.switchTo(s.address); setOpen(false); }} aria-label={`Use ${s.label}`}><b>{s.label}</b><code>{shortAddress(s.address)}</code></button>
          <button className="icon-button" aria-label={`Remove ${s.label}`} onClick={() => w.remove(s.address)}><Trash2 size={14}/></button></div>)}
      </div>}

      {showForm && <>
        {!w.address && <p>Connect a signing wallet to approve transactions, or follow a public address to view it.</p>}
        <div className="wallet-list"><strong>Signing wallets</strong>
          {adapters.length ? adapters.map(a => <button key={a.id} className="primary-button" disabled={Boolean(busy)} onClick={() => connectWith(a.id)}><ShieldCheck size={15}/> {busy === a.id ? 'Waiting for wallet…' : `Connect ${a.name}`}</button>)
            : <div className="wallet-item"><button disabled><b>Rialo Wallet</b><small>Available when Rialo launches</small></button></div>}
        </div>
        <div className="wallet-list"><strong>Watch-only</strong>
          <input id="wallet-address" className="wallet-input" value={value} onChange={e => setValue(e.target.value)} onKeyDown={e => e.key === 'Enter' && addWatch()} placeholder="Public address" autoComplete="off" spellCheck={false}/>
          <input id="wallet-label" className="wallet-input" value={label} onChange={e => setLabel(e.target.value)} maxLength={30} placeholder="Name (optional)"/>
          {error && <div className="error-box">{error}</div>}
          <button className="wallet-secondary" onClick={addWatch} disabled={!value.trim()}>Follow address</button>
          <small>Never paste a seed phrase or private key. PaydFinance only needs a public address.</small>
        </div>
      </>}

      {w.address && <div className="wallet-actions">
        {!adding && <button className="wallet-secondary" onClick={() => setAdding(true)}>Add or switch wallet</button>}
        <button className="wallet-secondary" onClick={() => { w.disconnect(); setOpen(false); }}>Disconnect</button>
      </div>}
    </div>}
  </div>;
}
