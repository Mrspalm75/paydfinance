import { RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import { openWalletMenu, shortAddress, useRialoAccount, useWallet } from '../lib/wallet';
import { useRialoStatus } from '../lib/useRialoStatus';

export default function WalletSummary() {
  const w = useWallet(); const status = useRialoStatus(); const acct = useRialoAccount(w.address);
  if (!w.address) return <div className="panel" style={{ marginBottom: 15 }}><div className="panel-heading"><div><h3>Your wallet</h3><p>Connect a wallet to see your balance and approve transactions.</p></div><button className="primary-button" onClick={openWalletMenu}>Connect wallet</button></div></div>;
  return <div className="panel" style={{ marginBottom: 15 }}>
    <div className="panel-heading"><div><h3>Your wallet</h3><p>{w.label} · {w.canSign ? 'Signing wallet' : 'Watch-only'} · <code>{shortAddress(w.address)}</code></p></div>
      <button className="icon-button" aria-label="Refresh balance" onClick={() => acct.refetch()} disabled={!status.data?.reachable}><RefreshCw size={15} className={acct.isFetching ? 'spin' : ''}/></button></div>
    <div className="stat-value" style={{ margin: '12px 0 4px' }}>{acct.data?.balanceRlo != null ? `${acct.data.balanceRlo} RLO` : '—'}</div>
    <small className="doc-p">{acct.data ? `Updated ${new Date(acct.data.fetchedAt).toLocaleTimeString()}` : status.data?.reachable ? 'Loading balance…' : 'Balance appears when Rialo mainnet is live.'}</small>
    <div className="suggestion-row"><Link className="suggestion" to="/send">Send</Link><Link className="suggestion" to="/swap">Swap</Link><Link className="suggestion" to="/sell">Sell</Link><Link className="suggestion" to="/bridge">Bridge</Link></div>
  </div>;
}
