export const assets = [
  { symbol: 'BTC', name: 'Bitcoin', price: '$67,420.80', change: '+2.41%', positive: true, allocation: 42 },
  { symbol: 'ETH', name: 'Ethereum', price: '$3,521.16', change: '+1.82%', positive: true, allocation: 28 },
  { symbol: 'SOL', name: 'Solana', price: '$148.32', change: '-0.64%', positive: false, allocation: 18 },
  { symbol: 'USDC', name: 'USD Coin', price: '$1.00', change: '0.01%', positive: true, allocation: 12 },
];

export const chartData = [
  { day: 'Mon', value: 42 }, { day: 'Tue', value: 48 }, { day: 'Wed', value: 45 },
  { day: 'Thu', value: 56 }, { day: 'Fri', value: 53 }, { day: 'Sat', value: 64 },
  { day: 'Sun', value: 71 },
];

export const activity = [
  { title: 'Portfolio sync', detail: 'Wallet snapshot refreshed', time: 'Today, 09:42', amount: 'Completed' },
  { title: 'BTC price alert', detail: 'BTC crossed your watch level', time: 'Today, 08:15', amount: 'Triggered' },
  { title: 'Weekly insight', detail: 'AI portfolio summary generated', time: 'Yesterday', amount: 'Ready' },
];
