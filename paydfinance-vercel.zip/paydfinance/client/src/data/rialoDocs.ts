// Rialo developer guide content. Sources are listed at the bottom of the page.
// Facts here come from the published rialo-cdk (Rust) and rialo-py-cdk (Python) documentation and rialo.io.
// Re-check against https://www.rialo.io/docs before production use.
export interface DocBlock { t: 'h' | 'h3' | 'p' | 'note' | 'table' | 'code' | 'ul' | 'ol'; text?: string; tone?: 'warn' | 'safe' | 'info'; head?: string[]; rows?: string[][]; title?: string; lang?: string; items?: string[]; }
export interface DocTab { id: string; label: string; blocks: DocBlock[]; }
export const rialoDocs: { sources: { title: string; url: string }[]; tabs: DocTab[] } = {
 "sources": [
  {
   "title": "rialo-cdk (Rust) on docs.rs",
   "url": "https://docs.rs/crate/rialo-cdk/latest/source/README.md"
  },
  {
   "title": "rialo-py-cdk on PyPI",
   "url": "https://pypi.org/project/rialo-py-cdk/0.21.0a0/"
  },
  {
   "title": "Introducing Rialo (rialo.io)",
   "url": "https://www.rialo.io/posts/introducing-rialo/"
  }
 ],
 "tabs": [
  {
   "id": "network",
   "label": "Network & RPC",
   "blocks": [
    {
     "t": "h",
     "text": "Rialo network and RPC configuration"
    },
    {
     "t": "p",
     "text": "Rialo is a layer-1 network built around reactive transactions, HTTPS calls from smart contracts and a RISC-V execution environment. Applications talk to a Rialo node over HTTP JSON-RPC."
    },
    {
     "t": "note",
     "tone": "warn",
     "text": "Availability: Rialo announced a private DevNet. The sources used for this page do not confirm that testnet or mainnet are publicly reachable. The endpoints below come from the official SDK helpers. Verify them against Rialo's own documentation before relying on them."
    },
    {
     "t": "h3",
     "text": "Networks"
    },
    {
     "t": "table",
     "head": [
      "Network",
      "RPC URL",
      "Notes"
     ],
     "rows": [
      [
       "localnet",
       "http://127.0.0.1:4104",
       "SDK default for a local node"
      ],
      [
       "devnet",
       "https://api.devnet.rialo.xyz",
       "Listed in the SDK"
      ],
      [
       "testnet",
       "https://api.testnet.rialo.xyz",
       "Listed in the SDK"
      ],
      [
       "mainnet",
       "https://api.mainnet.rialo.xyz",
       "Listed in the SDK; confirm it is live"
      ]
     ]
    },
    {
     "t": "p",
     "text": "No chain ID is published in the sources, so PaydFinance does not assume one. Leave RIALO_CHAIN_ID empty until the official documentation states it."
    },
    {
     "t": "h3",
     "text": "Connect PaydFinance to a node"
    },
    {
     "t": "p",
     "text": "Set these in server/.env. The adapter stays off until RIALO_ENABLED is true and an RPC URL is present."
    },
    {
     "t": "code",
     "title": "server/.env",
     "lang": "env",
     "text": "RIALO_ENABLED=true\nRIALO_NETWORK=devnet\nRIALO_RPC_URL=https://api.devnet.rialo.xyz\nRIALO_CHAIN_ID="
    },
    {
     "t": "h3",
     "text": "Transport"
    },
    {
     "t": "p",
     "text": "Every call is an HTTP POST with a JSON body. The id is a counter that starts at 1 and params are usually wrapped in an array."
    },
    {
     "t": "code",
     "title": "Health check",
     "lang": "bash",
     "text": "curl -s https://api.devnet.rialo.xyz \\\n  -H 'Content-Type: application/json' \\\n  -d '{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"getHealth\",\"params\":[{}]}'"
    },
    {
     "t": "h3",
     "text": "Units"
    },
    {
     "t": "p",
     "text": "The smallest unit is the kelvin. 1 RLO = 1,000,000,000 kelvin. All RPC amounts are in kelvin, and PaydFinance converts balances to RLO for display."
    }
   ]
  },
  {
   "id": "wallet",
   "label": "Wallet & Transactions",
   "blocks": [
    {
     "t": "h",
     "text": "Wallet and transaction integration"
    },
    {
     "t": "note",
     "tone": "safe",
     "text": "PaydFinance never holds private keys or seed phrases and never submits transactions from the server. POST /api/rialo/transactions always returns 501. Signing happens in a user-controlled wallet or in your own client code."
    },
    {
     "t": "h3",
     "text": "Keys"
    },
    {
     "t": "ul",
     "items": [
      "Keys derive on BIP44 coin type 756: m/44'/756'/{index}'. Keys from other coin types are not compatible.",
      "The low-level API uses a 64-byte keypair (32-byte secret followed by the 32-byte public key). Keyring provider calls take only the 32-byte secret.",
      "The Wallet and Account names in the SDKs are deprecated aliases for Keyring and DerivedKeypair."
     ]
    },
    {
     "t": "h3",
     "text": "Sending a transfer"
    },
    {
     "t": "ol",
     "items": [
      "Fetch the config hash prefix from the node. Every transaction needs it, and live nodes reject the documentation example value.",
      "Build the transaction with the sender public key, a valid-from timestamp and the config hash.",
      "Add a transfer instruction. The amount is in kelvin.",
      "Sign with the keyring, then submit with send_transaction, or send_and_confirm_transaction to wait for confirmation.",
      "Check the result with getSignatureStatuses or getTransaction."
     ]
    },
    {
     "t": "code",
     "title": "Python (rialo-py-cdk), adapted from the SDK docs",
     "lang": "python",
     "text": "from rialo_py_cdk import (HttpRpcClient, InMemoryKeyringProvider,\n    TransactionBuilder, get_devnet_url, rlo_to_kelvin)\n\nprovider = InMemoryKeyringProvider()\nkeyring, mnemonic = provider.create_with_mnemonic(\"main\", 128, \"password\")\n\nclient = HttpRpcClient(get_devnet_url())\nconfig_hash = client.get_config_hash_prefix()\n\ntx_bytes = (\n    TransactionBuilder(keyring.get_public_key(), valid_from, config_hash)\n    .add_transfer_instruction(sender, recipient, int(rlo_to_kelvin(1.0)))\n    .sign_with_keyring(keyring)\n)\nsignature = client.send_transaction(tx_bytes)"
    },
    {
     "t": "p",
     "text": "valid_from, sender and recipient are values you supply. Check the SDK reference for their exact types."
    },
    {
     "t": "h3",
     "text": "Errors"
    },
    {
     "t": "p",
     "text": "The Python SDK raises RialoException with a code and message. Ranges: 1000 to 1999 transaction, 2000 to 2999 RPC, 3000 to 3999 configuration, 4000 to 4999 keyring, 5000 to 5999 encryption."
    },
    {
     "t": "code",
     "title": "Handling errors",
     "lang": "python",
     "text": "try:\n    signature = client.send_transaction(tx_bytes)\nexcept RialoException as exc:\n    print(exc.code, exc.message)"
    },
    {
     "t": "note",
     "tone": "info",
     "text": "The SDK blocks the calling thread. In an async app, run calls in a thread pool or run_in_executor."
    }
   ]
  },
  {
   "id": "contracts",
   "label": "Smart Contracts",
   "blocks": [
    {
     "t": "h",
     "text": "Smart contract integration"
    },
    {
     "t": "note",
     "tone": "warn",
     "text": "Not built into PaydFinance yet. The adapter is read-only. This page documents how contracts work on Rialo so you can plan the integration."
    },
    {
     "t": "h3",
     "text": "Program loaders"
    },
    {
     "t": "table",
     "head": [
      "Loader",
      "Runs",
      "Notes"
     ],
     "rows": [
      [
       "LoaderV4",
       "eBPF programs",
       "Default"
      ],
      [
       "RiscV",
       "RISC-V / PolkaVM programs",
       "Select with with_loader_type"
      ],
      [
       "RexWasmV1",
       "WASM programs",
       "Via the REX loader (Rust SDK)"
      ]
     ]
    },
    {
     "t": "h3",
     "text": "Deploy and invoke"
    },
    {
     "t": "code",
     "title": "Python (rialo-py-cdk), adapted from the SDK docs",
     "lang": "python",
     "text": "from rialo_py_cdk import ProgramDeployment, ProgramInvocation, PyLoaderType\n\ndeployment = ProgramDeployment(\"/path/to/program.so\")\ndeployment.with_loader_type(PyLoaderType.RiscV)\nprogram_id = deployment.deploy_with_keyring(client, keyring)\n\ninvocation = ProgramInvocation(program_id)\ninvocation.add_writable_account(account_a)\ninvocation.add_readonly_account(account_b)\ninvocation.with_data(instruction_data_bytes)\nsignature = invocation.invoke_with_keyring(client, keyring)"
    },
    {
     "t": "h3",
     "text": "Reactive transactions (REX)"
    },
    {
     "t": "p",
     "text": "Rialo contracts can react to conditions without off-chain monitoring. Three RPC methods let you inspect them."
    },
    {
     "t": "ul",
     "items": [
      "getSubscription: look up a subscription by subscriber and nonce.",
      "getTriggeredTransactions: list transactions a subscription account triggered, with an optional limit.",
      "getWorkflowLineage: walk the workflow graph."
     ]
    },
    {
     "t": "h3",
     "text": "Confidential inputs"
    },
    {
     "t": "p",
     "text": "For programs that run in a trusted execution environment, encrypt_secret(secret, sender_pubkey, tee_pubkey) performs HPKE encryption so a secret is readable only by that program."
    }
   ]
  },
  {
   "id": "api",
   "label": "API Reference",
   "blocks": [
    {
     "t": "h",
     "text": "API references and examples"
    },
    {
     "t": "h3",
     "text": "PaydFinance endpoints"
    },
    {
     "t": "table",
     "head": [
      "Endpoint",
      "Purpose",
      "Notes"
     ],
     "rows": [
      [
       "GET /api/rialo/status",
       "Adapter and node status",
       "Also at /api/health/rialo"
      ],
      [
       "GET /api/rialo/account/:address",
       "Balance for a public address",
       "Read-only"
      ],
      [
       "POST /api/rialo/transactions",
       "Submit a transaction",
       "Always 501. Sign in a user wallet"
      ]
     ]
    },
    {
     "t": "code",
     "title": "Read an account through PaydFinance",
     "lang": "bash",
     "text": "curl http://localhost:4000/api/rialo/status\ncurl http://localhost:4000/api/rialo/account/<PUBLIC_ADDRESS>"
    },
    {
     "t": "code",
     "title": "Response shape",
     "lang": "json",
     "text": "{\n  \"address\": \"<PUBLIC_ADDRESS>\",\n  \"balanceKelvin\": \"1500000000\",\n  \"balanceRlo\": \"1.5\",\n  \"accountInfo\": null,\n  \"fetchedAt\": \"2026-11-13T09:00:00.000Z\",\n  \"source\": \"rialo-rpc\"\n}"
    },
    {
     "t": "code",
     "title": "From your frontend",
     "lang": "ts",
     "text": "const res = await fetch(`${API_BASE}/rialo/account/${address}`);\nif (!res.ok) throw new Error((await res.json()).error);\nconst { balanceRlo } = await res.json();"
    },
    {
     "t": "h3",
     "text": "Node JSON-RPC methods"
    },
    {
     "t": "p",
     "text": "Method names and parameters below come from an older published version of the Rust client. Confirm them against the current SDK before depending on them."
    },
    {
     "t": "table",
     "head": [
      "Method",
      "Params",
      "Used by PaydFinance"
     ],
     "rows": [
      [
       "getHealth",
       "[{}]",
       "Yes"
      ],
      [
       "getBalance",
       "[{pubkey}]",
       "Yes"
      ],
      [
       "getAccountInfo",
       "[{address, config:{encoding:\"base64\"}}]",
       "Planned"
      ],
      [
       "getMultipleAccounts",
       "[{addresses}]",
       "No"
      ],
      [
       "getAccountsByOwner",
       "[{owner, filter, base64}]",
       "No"
      ],
      [
       "getBlockHeight",
       "[{min_context_slot}]",
       "No"
      ],
      [
       "getEpochInfo",
       "[{config}]",
       "No"
      ],
      [
       "getTransaction",
       "[{signature, encoding:\"json\"}]",
       "No"
      ],
      [
       "getTransactionCount",
       "[{}]",
       "No"
      ],
      [
       "getSignatureStatuses",
       "[{signatures, config:null}]",
       "No"
      ],
      [
       "getSignaturesForAddress",
       "[{address, config}]",
       "No"
      ],
      [
       "getFeeForMessage",
       "[{message}]",
       "No"
      ],
      [
       "getMinimumBalanceForRentExemption",
       "[{data_length}]",
       "No"
      ],
      [
       "isBlockhashValid",
       "[{blockhash}]",
       "No"
      ],
      [
       "sendTransaction",
       "[{transaction (base64), options}]",
       "Never (client-side signing)"
      ],
      [
       "requestAirdrop",
       "[{pubkey, amount}]",
       "No (test networks)"
      ],
      [
       "getSubscription",
       "[{subscriber, nonce}]",
       "No"
      ],
      [
       "getTriggeredTransactions",
       "[pubkey, limit?]",
       "No"
      ],
      [
       "getWorkflowLineage",
       "[request]",
       "No"
      ]
     ]
    }
   ]
  }
 ]
};
