import { useQuery } from '@tanstack/react-query';
import { api } from './api';

export interface MarketAsset { symbol: string; name: string; id: string; price: number | null; change24h: number | null; marketCap: number | null; volume24h: number | null; }
export interface MarketOverview { live: boolean; source: string; fetchedAt: string; assets: MarketAsset[]; }
export interface ChartPoint { t: number; price: number; }
export interface MarketChart { points: ChartPoint[]; symbol: string; days: number; source: string; }

export const useMarkets = () => useQuery({ queryKey: ['markets'], queryFn: () => api<MarketOverview>('/markets/overview'), refetchInterval: 30_000, retry: 1 });
export const useChart = (id: string, days: number) => useQuery({ queryKey: ['chart', id, days], queryFn: () => api<MarketChart>(`/markets/chart?id=${id}&days=${days}`), refetchInterval: 300_000, retry: 1 });

export const usd = (n: number | null | undefined) => n == null ? '—' : n >= 1000 ? n.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }) : n.toLocaleString('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: n < 2 ? 4 : 2 });
export const pct = (n: number | null | undefined) => n == null ? '—' : `${n >= 0 ? '+' : ''}${n.toFixed(2)}%`;
export const compact = (n: number | null | undefined) => n == null ? '—' : new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', notation: 'compact', maximumFractionDigits: 2 }).format(n);
