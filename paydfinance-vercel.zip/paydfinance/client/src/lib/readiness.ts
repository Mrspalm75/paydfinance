import { useQuery } from '@tanstack/react-query';
import { api } from './api';
import { adapterFor, type TxIntent } from './walletAdapter';

export interface Readiness {
  node: { configured: boolean; reachable: boolean | null; network: string | null };
  features: Record<'send' | 'swap' | 'sell' | 'bridge', { ready: boolean; requires: string[] }>;
}
/**
 * A feature is live only when the server says the Rialo node and venue are ready AND a signing wallet adapter
 * exists. It re-checks every 30 seconds, so the page switches on by itself once Rialo is reachable.
 */
export function useReadiness(kind: TxIntent['kind']) {
  const q = useQuery({ queryKey: ['readiness'], queryFn: () => api<Readiness>('/rialo/readiness'), refetchInterval: 30_000, retry: false });
  const f = q.data?.features[kind];
  const adapter = adapterFor(kind);
  const pending = [...(f?.requires ?? (q.isError ? ['Payd API is unreachable'] : ['Checking Rialo status'])), ...(adapter ? [] : ['A Rialo signing wallet adapter must be added'])];
  return { ready: Boolean(f?.ready && adapter), pending, loading: q.isLoading };
}
