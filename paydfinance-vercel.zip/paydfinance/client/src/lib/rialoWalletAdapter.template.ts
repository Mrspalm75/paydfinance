/**
 * TEMPLATE. Copy to rialoWalletAdapter.ts when Rialo publishes an official wallet / JS SDK, fill in the
 * TODOs from the official documentation, then register it in walletAdapter.ts: `export const adapters = [rialoWallet];`
 * Do not guess method names. Every function below must call the wallet's own approval prompt.
 */
import type { TxIntent, WalletAdapter } from './walletAdapter';

export const rialoWallet: WalletAdapter = {
  id: 'rialo-wallet',
  name: 'Rialo Wallet', // TODO official name
  supports: (kind) => kind === 'send', // TODO add 'swap' | 'sell' | 'bridge' once the venue/provider is implemented
  async connect() {
    // TODO: call the official connect API, return the public address.
    throw new Error('Not implemented');
  },
  async approveAndSend(_intent: TxIntent) {
    // TODO: build the transaction for the intent (send = transfer instruction, amount in kelvin),
    // ask the wallet to sign and submit, and return the signature. Reject if the user declines.
    throw new Error('Not implemented');
  },
};
