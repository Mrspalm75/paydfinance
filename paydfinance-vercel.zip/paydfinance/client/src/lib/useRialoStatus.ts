import { useQuery } from '@tanstack/react-query';
import { api } from './api';

export interface RialoStatus {
  configured: boolean; reachable: boolean | null; network: string | null; chainId: string | null;
  mode: 'unavailable' | 'read-only'; writesEnabled: false; message: string;
}

export function useRialoStatus() {
  return useQuery({ queryKey: ['rialo-status'], queryFn: () => api<RialoStatus>('/rialo/status'), refetchInterval: 60_000, retry: false });
}

export function rialoLabel(s?: RialoStatus, failed?: boolean) {
  if (failed || !s) return { title: 'API unreachable', tone: 'status-pending', dot: 'Unknown' };
  if (!s.configured) return { title: 'Rialo network', tone: 'status-pending', dot: 'Awaiting mainnet' };
  if (s.reachable) return { title: s.network ? `Rialo ${s.network}` : 'Rialo node', tone: 'status-ready', dot: 'Connected · read-only' };
  return { title: 'Node unreachable', tone: 'status-pending', dot: 'Offline' };
}
