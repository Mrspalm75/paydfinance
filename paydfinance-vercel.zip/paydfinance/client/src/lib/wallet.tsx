import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from './api';
import { useRialoStatus } from './useRialoStatus';
import { adapters, type WalletAdapter } from './walletAdapter';

/**
 * Wallet connection.
 *  - "adapter": a signing wallet registered in walletAdapter.ts (empty until Rialo publishes an official wallet).
 *  - "watch": a PUBLIC address saved in this browser. It can view balances but cannot approve anything.
 * The app never asks for, stores or sends private keys or seed phrases. Only public addresses, labels and the
 * connection mode are saved, in localStorage, and the state syncs across tabs.
 */
const KEY = 'payd.wallet.v2'; const OLD_KEY = 'payd.wallet.address';
const VALID = /^[A-Za-z0-9]{20,100}$/;
export const isValidAddress = (a: string) => VALID.test(a.trim());
export const shortAddress = (a: string) => a.length > 14 ? `${a.slice(0, 6)}…${a.slice(-4)}` : a;
export const WALLET_OPEN_EVENT = 'payd:open-wallet';
/** Any page can call this to open the wallet menu in the top bar. */
export const openWalletMenu = () => window.dispatchEvent(new Event(WALLET_OPEN_EVENT));

export type WalletMode = 'watch' | 'adapter';
export interface SavedWallet { address: string; label: string; mode: WalletMode; adapterId?: string; }
interface Stored { active: string; saved: SavedWallet[]; }

interface WalletCtx {
  address: string; mode: WalletMode | null; label: string; adapter: WalletAdapter | undefined;
  /** True only when a signing adapter is connected. Watch-only wallets can never approve transactions. */
  canSign: boolean; saved: SavedWallet[];
  connectWatch: (address: string, label?: string) => string | null;
  connectAdapter: (id: string) => Promise<string | null>;
  switchTo: (address: string) => void; remove: (address: string) => void; disconnect: () => void;
}
const noop = () => null;
const Ctx = createContext<WalletCtx>({ address: '', mode: null, label: '', adapter: undefined, canSign: false, saved: [], connectWatch: noop, connectAdapter: async () => null, switchTo: () => {}, remove: () => {}, disconnect: () => {} });

function load(): Stored {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const p = JSON.parse(raw) as Stored;
      const saved = (p.saved ?? []).filter(w => isValidAddress(w.address));
      return { saved, active: saved.some(w => w.address === p.active) ? p.active : '' };
    }
    const old = localStorage.getItem(OLD_KEY); // migrate the first version
    if (old && isValidAddress(old)) return { active: old, saved: [{ address: old, label: 'Watch wallet', mode: 'watch' }] };
  } catch { /* storage unavailable or corrupt */ }
  return { active: '', saved: [] };
}
function persist(s: Stored) { try { localStorage.setItem(KEY, JSON.stringify(s)); localStorage.removeItem(OLD_KEY); } catch { /* ignore */ } }

export function WalletProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Stored>({ active: '', saved: [] });
  useEffect(() => {
    setState(load());
    const sync = (e: StorageEvent) => { if (e.key === KEY || e.key === null) setState(load()); };
    window.addEventListener('storage', sync); return () => window.removeEventListener('storage', sync);
  }, []);
  const update = useCallback((fn: (s: Stored) => Stored) => setState(prev => { const next = fn(prev); persist(next); return next; }), []);

  const connectWatch = useCallback((a: string, label?: string) => {
    const address = a.trim();
    if (!isValidAddress(address)) return 'Enter a public address (letters and numbers, 20 to 100 characters). Never paste a seed phrase or private key.';
    update(s => {
      const existing = s.saved.find(w => w.address === address);
      const saved = existing ? s.saved : [...s.saved, { address, label: label?.trim() || `Watch wallet ${s.saved.filter(w => w.mode === 'watch').length + 1}`, mode: 'watch' as const }].slice(-8);
      return { active: address, saved };
    });
    return null;
  }, [update]);

  const connectAdapter = useCallback(async (id: string) => {
    const ad = adapters.find(x => x.id === id);
    if (!ad) return 'That wallet is not available.';
    try {
      const { address } = await ad.connect();
      if (!isValidAddress(address)) return 'The wallet returned an invalid address.';
      update(s => ({ active: address, saved: [...s.saved.filter(w => w.address !== address), { address, label: ad.name, mode: 'adapter', adapterId: ad.id }].slice(-8) }));
      return null;
    } catch (e) { return e instanceof Error ? e.message : 'The wallet declined the connection.'; }
  }, [update]);

  const switchTo = useCallback((address: string) => update(s => s.saved.some(w => w.address === address) ? { ...s, active: address } : s), [update]);
  const remove = useCallback((address: string) => update(s => ({ active: s.active === address ? '' : s.active, saved: s.saved.filter(w => w.address !== address) })), [update]);
  const disconnect = useCallback(() => update(s => ({ ...s, active: '' })), [update]);

  const value = useMemo<WalletCtx>(() => {
    const w = state.saved.find(x => x.address === state.active);
    const adapter = w?.mode === 'adapter' ? adapters.find(a => a.id === w.adapterId) : undefined;
    return { address: w?.address ?? '', mode: w?.mode ?? null, label: w?.label ?? '', adapter, canSign: Boolean(adapter), saved: state.saved, connectWatch, connectAdapter, switchTo, remove, disconnect };
  }, [state, connectWatch, connectAdapter, switchTo, remove, disconnect]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export const useWallet = () => useContext(Ctx);

export interface RialoAccount { address: string; balanceKelvin: string | null; balanceRlo: string | null; fetchedAt: string; }
export function useRialoAccount(address: string) {
  const status = useRialoStatus();
  return useQuery({
    queryKey: ['rialo-account', address], enabled: Boolean(address) && status.data?.reachable === true,
    queryFn: () => api<RialoAccount>(`/rialo/account/${encodeURIComponent(address)}`), refetchInterval: 60_000, retry: false,
  });
}
