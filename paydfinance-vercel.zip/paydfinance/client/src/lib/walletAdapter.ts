/**
 * Signing boundary.
 *
 * Every send, swap and bridge ends at `adapter.approveAndSend(intent)`: the connected wallet shows its own
 * permission prompt and signs. PaydFinance never sees keys and the server never signs.
 *
 * No Rialo wallet standard, JS SDK, swap venue or bridge has been verified yet, so `adapters` is empty and
 * the UI keeps the final button disabled. To enable signing, add an adapter for the official Rialo wallet
 * (and a swap/bridge venue for those intents) here. Nothing else in the UI needs to change.
 */
export type TxIntent =
  | { kind: 'send'; to: string; amountRlo: string; amountKelvin: string }
  | { kind: 'swap'; from: string; to: string; amountIn: string; minReceive: string; slippagePct: number }
  | { kind: 'sell'; asset: string; amount: string; receive: string; minReceive: string; slippagePct: number }
  | { kind: 'bridge'; asset: string; amount: string; fromNetwork: string; toNetwork: string; destination: string };

export interface WalletAdapter {
  id: string; name: string;
  supports(kind: TxIntent['kind']): boolean;
  connect(): Promise<{ address: string }>;
  /** Must trigger the wallet's own approval prompt. Resolve with a transaction signature or reject if declined. */
  approveAndSend(intent: TxIntent): Promise<{ signature: string }>;
}

export const adapters: WalletAdapter[] = [];
/** Call this once the official Rialo wallet SDK is verified (see rialoWalletAdapter.template.ts). */
export const registerWalletAdapter = (a: WalletAdapter) => { if (!adapters.some(x => x.id === a.id)) adapters.push(a); };
export const adapterFor = (kind: TxIntent['kind']) => adapters.find(a => a.supports(kind));

/** Parse a decimal RLO string (up to 9 places) into kelvin without floating point. 1 RLO = 1,000,000,000 kelvin. */
export function rloToKelvin(rlo: string): string | null {
  if (!/^\d+(\.\d{1,9})?$/.test(rlo)) return null;
  const [w, f = ''] = rlo.split('.');
  return (BigInt(w) * 1_000_000_000n + BigInt(f.padEnd(9, '0'))).toString();
}
