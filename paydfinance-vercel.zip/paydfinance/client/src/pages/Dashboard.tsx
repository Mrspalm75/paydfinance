import { Activity, ArrowUpRight, BrainCircuit, CircleDollarSign, ShieldCheck, Wallet } from 'lucide-react';
import StatCard from '../components/StatCard';
import ChartPanel from '../components/ChartPanel';
import AssetTable from '../components/AssetTable';
import SectionTitle from '../components/SectionTitle';
import { activity } from '../data/demo';
import { openWalletMenu, useRialoAccount, useWallet } from '../lib/wallet';
import { useMarkets, usd, pct } from '../lib/market';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  const { address } = useWallet(); const acct = useRialoAccount(address);
  const { data: m, isError } = useMarkets(); const btc = m?.assets.find(a=>a.symbol==='BTC'); const eth = m?.assets.find(a=>a.symbol==='ETH');
  return <div className="page-content">
    <div className="welcome-row"><div><div className="eyebrow"><span className="status-dot"/> YOUR FINANCIAL COMMAND CENTER</div><h1>Good morning<span className="heading-dot">.</span></h1><p>Here’s your financial snapshot. Connect your wallet and data sources to get started.</p></div><Link className="primary-button" to="/ai-mentor"><BrainCircuit size={16}/> Ask AI Mentor</Link></div>
    {m ? <div className="demo-banner" style={{borderColor:'#1f4a3b',background:'#10201b'}}><span className="banner-icon" style={{color:'#4ed5a0'}}><Activity size={17}/></span><div><strong style={{color:'#bdeed9'}}>Live market data</strong><p style={{color:'#8fb5a5'}}>Prices from {m.source}, refreshed every 30 seconds. Last update {new Date(m.fetchedAt).toLocaleTimeString()}. Portfolio figures need a connected wallet.</p></div><span className="demo-label" style={{color:'#4ed5a0'}}>LIVE</span></div>
    : <div className="demo-banner"><span className="banner-icon"><Activity size={17}/></span><div><strong>{isError ? 'Live data unavailable' : 'Loading live data…'}</strong><p>{isError ? 'Could not reach the market data service. Check that the API is running.' : 'Fetching current prices.'}</p></div></div>}
    <div className="stats-grid">
      <StatCard label="Bitcoin" value={usd(btc?.price)} change={pct(btc?.change24h)} icon={<Wallet size={18}/>} />
      <StatCard label="Ethereum" value={usd(eth?.price)} change={pct(eth?.change24h)} icon={<Activity size={18}/>} tone="green"/>
      <StatCard label="Tracked assets" value={m ? String(m.assets.length) : '—'} change="Live market feed" icon={<CircleDollarSign size={18}/>} tone="blue"/>
      <StatCard label="Rialo balance" value={acct.data?.balanceRlo != null ? `${acct.data.balanceRlo} RLO` : '—'} change={address ? (acct.data ? 'Watch-only wallet' : 'Awaiting Rialo network') : 'Connect a wallet'} icon={<ShieldCheck size={18}/>} tone="amber"/>
    </div>
    <div className="dashboard-grid"><ChartPanel/><div className="panel insight-panel"><div className="panel-heading"><div><h3>AI daily insight</h3><p>Personalized intelligence</p></div><span className="ai-chip"><BrainCircuit size={13}/> AI</span></div><div className="insight-glow"><BrainCircuit size={25}/></div><h4>Your financial picture, made clearer.</h4><p>Connect a wallet and enable a market data provider to receive portfolio-aware insights grounded in your actual data.</p><Link to="/ai-mentor" className="inline-link">Start a conversation <ArrowUpRight size={14}/></Link><div className="insight-foot"><span className="status-dot"/> AI engine ready to configure</div></div></div>
    <AssetTable/>
    <div className="bottom-grid">
      <div className="panel activity-panel"><div className="panel-heading"><div><h3>Recent activity</h3><p>Latest workspace events</p></div><Link to="/transactions" className="text-action">View all ↗</Link></div>
        {activity.map(item => <div className="activity-row" key={item.title}><div className="activity-icon"><Activity size={16}/></div><div className="activity-copy"><strong>{item.title}</strong><small>{item.detail}</small></div><div className="activity-meta"><strong>{item.amount}</strong><small>{item.time}</small></div></div>)}
      </div>
      <div className="panel quick-panel"><div className="panel-heading"><div><h3>Quick actions</h3><p>Jump into your workspace</p></div></div>
        <button className="quick-link" style={{ width: '100%', background: 'none', border: 0, textAlign: 'left', font: 'inherit' }} onClick={openWalletMenu}><Wallet size={17}/> {address ? 'Manage wallet' : 'Connect a wallet'} <span>↗</span></button>
        <Link to="/watchlist" className="quick-link"><Activity size={17}/> Create price alert <span>↗</span></Link>
        <Link to="/automation" className="quick-link"><BrainCircuit size={17}/> Build automation <span>↗</span></Link>
      </div>
    </div>
  </div>;
}
