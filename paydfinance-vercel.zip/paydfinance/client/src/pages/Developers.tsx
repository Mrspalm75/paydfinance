import { useState } from 'react';
import { BookOpen, Check, Copy, ExternalLink } from 'lucide-react';
import SectionTitle from '../components/SectionTitle';
import { rialoDocs, type DocBlock } from '../data/rialoDocs';

const links = [
  ['Official documentation', 'https://www.rialo.io/docs', 'Concepts, APIs and guides. Start here.'],
  ['Developer portal', 'https://www.rialo.io/for-devs', 'Entry point for builders.'],
  ['Learn', 'https://learn.rialo.io', 'Tutorials and learning resources.'],
  ['Playground', 'https://playground.rialo.io', 'Try Rialo in the browser.'],
  ['GitHub', 'https://github.com/rialo', 'Official repositories.'],
  ['Client SDK (rialo-cdk)', 'https://docs.rs/crate/rialo-cdk/latest', 'Rust client source, including the RPC methods this app uses.'],
  ['Blog and announcements', 'https://www.rialo.io/blog', 'Launch news and updates.'],
  ['Community', 'https://discord.gg/RialoProtocol', 'Discord for developer questions.'],
];
const steps = [
  'Read the official docs and confirm the network name, RPC endpoint and chain ID.',
  'Set RIALO_ENABLED, RIALO_RPC_URL, RIALO_NETWORK and RIALO_CHAIN_ID in server/.env.',
  'Start the API and open /api/rialo/status. It should report reachable.',
  'Connect a wallet (watch-only) from the top bar and compare its balance with the official explorer.',
  'Confirm response shapes and the kelvin to RLO conversion before showing balances to users.',
  'Add integration tests, then build wallet-signed transactions. The server never signs.',
];

function Code({ title, lang, text }: { title?: string; lang?: string; text: string }) {
  const [done, setDone] = useState(false);
  const copy = async () => { try { await navigator.clipboard.writeText(text); setDone(true); setTimeout(() => setDone(false), 1500); } catch { /* clipboard blocked */ } };
  return <div className="doc-code"><div className="doc-code-head"><span>{title || lang}</span><button onClick={copy} aria-label="Copy code">{done ? <Check size={14}/> : <Copy size={14}/>} {done ? 'Copied' : 'Copy'}</button></div><pre><code>{text}</code></pre></div>;
}
function Block({ b }: { b: DocBlock }) {
  switch (b.t) {
    case 'h': return <h2 className="doc-h">{b.text}</h2>;
    case 'h3': return <h3 className="doc-h3">{b.text}</h3>;
    case 'p': return <p className="doc-p">{b.text}</p>;
    case 'note': return <div className={`doc-note ${b.tone ?? 'info'}`}>{b.text}</div>;
    case 'ul': return <ul className="doc-list">{b.items!.map(i => <li key={i}>{i}</li>)}</ul>;
    case 'ol': return <ol className="doc-list">{b.items!.map(i => <li key={i}>{i}</li>)}</ol>;
    case 'code': return <Code title={b.title} lang={b.lang} text={b.text!}/>;
    case 'table': return <div className="table-scroll"><table className="doc-table"><thead><tr>{b.head!.map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{b.rows!.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{j === 0 || /^(http|\[)/.test(c) ? <code>{c}</code> : c}</td>)}</tr>)}</tbody></table></div>;
  }
}

export default function Developers() {
  const tabs = [...rialoDocs.tabs, { id: 'resources', label: 'Resources', blocks: [] }];
  const [tab, setTab] = useState(tabs[0].id);
  const current = tabs.find(t => t.id === tab)!;
  return <div className="page-content">
    <SectionTitle title="Rialo docs" subtitle="Network, wallets, contracts and APIs in one place."/>
    <div className="module-hero panel"><div className="module-icon"><BookOpen size={25}/></div><div><div className="eyebrow">RIALO FOR DEVELOPERS</div><h1>Build on Rialo</h1><p>A working guide to connecting PaydFinance to Rialo. Network details are not assumed in code, so confirm them with the official docs.</p></div></div>
    <div className="doc-tabs" role="tablist">{tabs.map(t => <button key={t.id} role="tab" aria-selected={t.id === tab} className={t.id === tab ? 'active' : ''} onClick={() => setTab(t.id)}>{t.label}</button>)}</div>
    <div className="panel doc-panel">
      {tab !== 'resources' ? <>
        {current.blocks.map((b, i) => <Block key={i} b={b}/>)}
        <div className="doc-sources"><strong>Sources</strong>{rialoDocs.sources.map(s => <a key={s.url} href={s.url} target="_blank" rel="noreferrer">{s.title} <ExternalLink size={12}/></a>)}</div>
      </> : <>
        <h2 className="doc-h">Official resources</h2>
        {links.map(([t, u, d]) => <a key={u} className="feature-row" href={u} target="_blank" rel="noreferrer"><span className="feature-check"><ExternalLink size={17}/></span><span><strong>{t}</strong><br/><small style={{ color: '#818ba0' }}>{d}</small></span></a>)}
        <h3 className="doc-h3">Go-live checklist</h3>
        {steps.map((s, i) => <div className="feature-row" key={s}><span className="feature-check">{i + 1}</span><span>{s}</span></div>)}
        <div className="integration-note"><div><strong>Before you start</strong><p>Public RPC endpoints and a mainnet launch are not stated on the public site. Use only values from the official docs.</p></div></div>
      </>}
    </div>
  </div>;
}
