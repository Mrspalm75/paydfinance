import { useQuery } from '@tanstack/react-query';
import SectionTitle from '../components/SectionTitle';
import { api } from '../lib/api';
import { compact, pct } from '../lib/market';

interface Indicator { id: string; label: string; unit: string; value: number | null; previous: number | null; date: string | null; }
interface Overview {
  macro: { configured: boolean; message?: string; source?: string; indicators: Indicator[] };
  crypto: { totalMarketCapUsd: number; volume24hUsd: number; btcDominance: number; ethDominance: number; change24h: number; source: string } | null;
  fetchedAt: string;
}
export default function Economy() {
  const { data, isError, isLoading } = useQuery({ queryKey: ['economy'], queryFn: () => api<Overview>('/economy/overview'), refetchInterval: 300_000, retry: 1 });
  const c = data?.crypto;
  return <div className="page-content"><SectionTitle title="Economic data" subtitle="Macro indicators and global crypto market context."/>
    {isError && <div className="error-box">Could not load economic data. Check that the API is running.</div>}
    {isLoading && <div className="doc-p">Loading…</div>}
    <div className="stats-grid">
      <div className="stat-card"><div className="stat-top"><span>Crypto market cap</span></div><div className="stat-value">{c ? compact(c.totalMarketCapUsd) : '—'}</div><div className="stat-change"><span>{c ? pct(c.change24h) : ''}</span><small> 24h</small></div></div>
      <div className="stat-card"><div className="stat-top"><span>24h volume</span></div><div className="stat-value">{c ? compact(c.volume24hUsd) : '—'}</div></div>
      <div className="stat-card"><div className="stat-top"><span>BTC dominance</span></div><div className="stat-value">{c ? `${c.btcDominance.toFixed(1)}%` : '—'}</div></div>
      <div className="stat-card"><div className="stat-top"><span>ETH dominance</span></div><div className="stat-value">{c ? `${c.ethDominance.toFixed(1)}%` : '—'}</div></div>
    </div>
    <div className="panel" style={{ marginTop: 15 }}>
      <div className="panel-heading"><div><h3>US economic indicators</h3><p>{data?.macro.configured ? data.macro.source : 'Not configured'}</p></div></div>
      {data && !data.macro.configured && <div className="doc-note warn" style={{ marginTop: 12 }}>{data.macro.message}</div>}
      {data?.macro.configured && <div className="table-scroll"><table><thead><tr><th>INDICATOR</th><th>LATEST</th><th>PREVIOUS</th><th>AS OF</th></tr></thead><tbody>
        {data.macro.indicators.map(i => <tr key={i.id}><td><strong>{i.label}</strong></td><td>{i.value == null ? '—' : `${i.value.toFixed(2)} ${i.unit}`}</td><td>{i.previous == null ? '—' : `${i.previous.toFixed(2)} ${i.unit}`}</td><td>{i.date ?? '—'}</td></tr>)}
      </tbody></table></div>}
      <small className="doc-p" style={{ display: 'block', marginTop: 12 }}>Economic figures are published with delays and revised. This is information, not investment advice.</small>
    </div>
  </div>;
}
