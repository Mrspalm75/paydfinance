import { useState } from 'react';
import { Activity, ArrowUpRight, BellRing, Bot, ChartNoAxesCombined, CheckCircle2, CircleDollarSign, FileText, Newspaper, Plus, ShieldAlert, Wallet, Workflow, Search, Sparkles, LockKeyhole } from 'lucide-react';
import ChartUpload from '../components/ChartUpload';
import SectionTitle from '../components/SectionTitle';
import { activity } from '../data/demo';
import { useMarkets, usd, pct } from '../lib/market';
import { api } from '../lib/api';
import { useWallet } from '../lib/wallet';
import WalletSummary from '../components/WalletSummary';
import { useQuery } from '@tanstack/react-query';
import { useRialoStatus, rialoLabel } from '../lib/useRialoStatus';

type ModuleId = 'ai-mentor'|'markets'|'analyzer'|'portfolio'|'finance'|'automation'|'risk'|'news'|'transactions'|'watchlist'|'reports'|'notifications'|'settings';
const config: Record<ModuleId, {title:string; desc:string; icon:typeof Activity; items:string[]; note:string}> = {
  'ai-mentor': {title:'AI Financial Mentor',desc:'Ask questions and turn financial data into clearer decisions.',icon:Bot,items:['Explain market movements in plain language','Summarize financial concepts and terminology','Review risk factors using connected data'],note:'Live AI responses require a backend OpenAI API key. No investment recommendations are guaranteed.'},
  markets: {title:'Market Intelligence',desc:'A unified view of the assets and market signals you follow.',icon:Activity,items:['Asset prices and 24-hour movements','Market capitalization and trading volume','Provider timestamps and source attribution'],note:'Prices are live from CoinGecko's public API. For production use, set MARKET_DATA_API_KEY or switch to a licensed provider.'},
  analyzer: {title:'AI Market Analyzer',desc:'Explore technical indicators and understand market structure.',icon:ChartNoAxesCombined,items:['Upload a chart screenshot and ask questions about it','Trend, support, resistance and pattern notes','Explanations of indicators such as RSI, MACD and moving averages'],note:'Chart upload needs live AI (OPENAI_API_KEY on the server). Analysis is read from the image only; it is educational, not investment advice.'},
  portfolio: {title:'Portfolio Manager',desc:'Bring your wallet activity and asset allocation into one view.',icon:Wallet,items:['Connect a supported wallet','View token balances and allocation','Track transactions and portfolio performance'],note:'Rialo wallet connection is not available yet. Balances appear here once Rialo mainnet is live.'},
  finance: {title:'Personal Finance',desc:'Understand your income, spending and financial goals.',icon:CircleDollarSign,items:['Income and expense categories','Monthly budgets and savings goals','Spending trends and summaries'],note:'Connect and configure your private finance data source before relying on these insights.'},
  automation: {title:'Smart Automation',desc:'Create rules and review actions before they are allowed to run.',icon:Workflow,items:['Price and portfolio condition triggers','Scheduled reminders and reports','Approval gates, limits and execution logs'],note:'Automation is in preview. This starter does not execute payments or trades.'},
  risk: {title:'Risk Center',desc:'Understand concentration, volatility and exposure across assets.',icon:ShieldAlert,items:['Asset concentration monitoring','Volatility and drawdown indicators','Risk alerts and scenario notes'],note:'Risk scores require actual holdings and validated price history. No risk score is currently calculated.'},
  news: {title:'News Intelligence',desc:'Follow financial events with source-linked summaries.',icon:Newspaper,items:['News grouped by asset and topic','AI summaries with original source links','Timestamped event context'],note:'News API is not configured. No live headlines are being displayed.'},
  transactions: {title:'Transaction Centre',desc:'Review transaction records from connected data sources.',icon:Activity,items:['Wallet activity and transfer records','Transaction status and confirmations','Searchable history and audit events'],note:'No wallet or chain data is connected. Demo activity is not an onchain record.'},
  watchlist: {title:'Watchlist & Alerts',desc:'Keep important assets close and define the signals you care about.',icon:BellRing,items:['Favourite asset lists','Custom price thresholds','In-app and email alert preferences'],note:'Alert persistence and delivery need authenticated backend configuration.'},
  reports: {title:'Reports & Insights',desc:'Turn financial activity into understandable reporting.',icon:FileText,items:['Daily and weekly portfolio summaries','Performance and allocation reports','Exportable financial snapshots'],note:'Reports will use your connected data. Current figures are sample UI content only.'},
  notifications: {title:'Notifications',desc:'Stay informed about activity and important changes.',icon:BellRing,items:['Price and market alerts','Automation and security events','Email and in-app preferences'],note:'Notification delivery providers are not configured in this starter.'},
  settings: {title:'Settings & Security',desc:'Manage your profile, access and connected services.',icon:LockKeyhole,items:['Account and authentication settings','Wallet and data-source permissions','Security and privacy controls'],note:'Configure Supabase Auth and production access policies before onboarding real users.'},
};

export default function ModulePage({id}:{id:ModuleId}) {
  const aiStatus = useQuery({ queryKey:['ai-status'], queryFn:()=>api<{configured:boolean;provider:string;model:string|null}>('/ai/status'), retry:false });
  const { data: mk, isError: mkErr } = useMarkets(); const rialo = useRialoStatus();
  const item = config[id]; const Icon = item.icon;
  const [prompt,setPrompt] = useState(''); const [answer,setAnswer] = useState(''); const [busy,setBusy] = useState(false); const [error,setError] = useState('');
  const wallet = useWallet(); const [addr,setAddr] = useState(wallet.address); const [acct,setAcct] = useState<{balanceKelvin:string|null;balanceRlo?:string|null;fetchedAt:string}|null>(null); const [acctErr,setAcctErr] = useState(''); const [acctBusy,setAcctBusy] = useState(false);
  async function lookup() {
    setAcctBusy(true); setAcctErr(''); setAcct(null);
    try { setAcct(await api(`/rialo/account/${encodeURIComponent(addr.trim())}`)); }
    catch(e) { setAcctErr(e instanceof Error ? e.message : 'Unable to reach Rialo.'); }
    finally { setAcctBusy(false); }
  }
  async function ask() {
    if (!prompt.trim()) return;
    setBusy(true); setError(''); setAnswer('');
    try { const result = await api<{answer:string}>('/ai/chat',{method:'POST',body:JSON.stringify({message:prompt})}); setAnswer(result.answer); }
    catch(e) { setError(e instanceof Error ? e.message : 'Unable to reach AI service.'); }
    finally { setBusy(false); }
  }
  return <div className="page-content">
    <SectionTitle title={item.title} subtitle={item.desc} action={<span className="module-status"><span className="status-dot"/> Workspace module</span>}/>
    <div className="module-hero panel"><div className="module-icon"><Icon size={25}/></div><div><div className="eyebrow">PAYDFINANCE WORKSPACE</div><h1>{item.title}</h1><p>{item.desc}</p></div></div>
    <div className="module-grid" style={{gridTemplateColumns:'1fr'}}>
      <div className="panel module-main"><div className="panel-heading"><div><h3>Capabilities</h3><p>Designed for the full product experience</p></div><span className="ai-chip"><Sparkles size={13}/> PAYD</span></div>
        {item.items.map((feature,i)=><div className="feature-row" key={feature}><span className="feature-check"><CheckCircle2 size={17}/></span><span>{feature}</span><span className="feature-number">0{i+1}</span></div>)}
        <div className="integration-note"><span className="note-icon"><Activity size={17}/></span><div><strong>Integration status</strong><p>{id==='ai-mentor' ? (aiStatus.isError ? 'Payd API is unreachable. Start the server to enable AI responses.' : aiStatus.data ? (aiStatus.data.configured ? `Live AI is on (${aiStatus.data.provider}, ${aiStatus.data.model}). Responses are informational; no investment recommendations are guaranteed.` : 'Live AI is off: set OPENAI_API_KEY on the server. No investment recommendations are guaranteed.') : 'Checking AI service…') : item.note}</p></div></div>
        <div className="side-callout"><LockKeyhole size={16}/><p>Never share private keys or seed phrases with PaydFinance or an AI assistant.</p></div>
      </div>
    </div>
    {id==='ai-mentor' && <div className="panel ai-workspace"><div className="panel-heading"><div><h3>Ask Payd AI</h3><p>Responses are informational, not personalized investment advice.</p></div><span className="ai-chip"><Bot size={13}/> AI ASSISTANT</span></div>
      <div className="suggestion-row">{['Explain portfolio diversification','What is RSI?','How should I read volatility?'].map(s=><button key={s} className="suggestion" onClick={()=>setPrompt(s)}>{s}</button>)}</div>
      <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Ask a financial question..." rows={3}/>
      <div className="ai-submit-row"><small>Do not include passwords, seed phrases or sensitive personal information.</small><button className="primary-button" disabled={busy || !prompt.trim()} onClick={ask}>{busy?'Thinking…':'Ask Payd AI'} <ArrowUpRight size={15}/></button></div>
      {error && <div className="error-box">{error}</div>}{answer && <div className="answer-box"><strong>Payd AI</strong><p>{answer}</p></div>}
    </div>}
    {(id==='portfolio' || id==='transactions') && <WalletSummary/>}
    {id==='portfolio' && <div className="panel ai-workspace"><div className="panel-heading"><div><h3>Rialo account lookup</h3><p>Read-only. Enter a public address. Never enter keys or seed phrases.</p></div><span className="ai-chip"><Wallet size={13}/> RIALO</span></div>
      <textarea value={addr} onChange={e=>setAddr(e.target.value)} placeholder="Public account address" rows={1}/>
      <div className="ai-submit-row"><small>{rialo.data?.configured ? `Network: ${rialo.data.network || 'unspecified'}` : 'Available when Rialo mainnet is live.'}</small><button className="primary-button" disabled={acctBusy || !addr.trim() || !rialo.data?.reachable} onClick={lookup}>{acctBusy?'Reading…':'Read account'} <ArrowUpRight size={15}/></button></div>
      {acctErr && <div className="error-box">{acctErr}</div>}
      {acct && <div className="answer-box"><strong>Balance</strong><p>{acct.balanceRlo != null ? `${acct.balanceRlo} RLO` : 'No balance returned'} ({acct.balanceKelvin ?? '—'} kelvin) · read {new Date(acct.fetchedAt).toLocaleString()}</p></div>}
    </div>}
    {id==='analyzer' && <ChartUpload/>}
    {id==='markets' && <div className="panel asset-panel"><div className="panel-heading"><div><h3>Tracked assets · live</h3><p>{mk ? `${mk.source} · updated ${new Date(mk.fetchedAt).toLocaleTimeString()}` : mkErr ? 'Live data unavailable' : 'Loading…'}</p></div></div><div className="table-scroll"><table><thead><tr><th>ASSET</th><th>PRICE</th><th>24H CHANGE</th></tr></thead><tbody>{mk?.assets.map(a=><tr key={a.symbol}><td><strong>{a.name} ({a.symbol})</strong></td><td>{usd(a.price)}</td><td className={(a.change24h ?? 0)>=0?'positive':'negative'}>{pct(a.change24h)}</td></tr>)}</tbody></table></div></div>}
    {id==='transactions' && <div className="panel activity-panel"><div className="panel-heading"><div><h3>Workspace activity</h3><p>These are local demo events, not blockchain transactions.</p></div></div>{activity.map(a=><div className="activity-row" key={a.title}><div className="activity-icon"><Activity size={16}/></div><div className="activity-copy"><strong>{a.title}</strong><small>{a.detail}</small></div><div className="activity-meta"><strong>{a.amount}</strong><small>{a.time}</small></div></div>)}</div>}
  </div>;
}
