import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowDownUp, ArrowUpRight } from 'lucide-react';
import SectionTitle from '../components/SectionTitle';
import ActivationBanner from '../components/ActivationBanner';
import ApprovalDialog from '../components/ApprovalDialog';
import { api } from '../lib/api';
import { useMarkets } from '../lib/market';
import { isValidAddress, openWalletMenu, useRialoAccount, useWallet } from '../lib/wallet';
import { rloToKelvin, type TxIntent } from '../lib/walletAdapter';

type Tab = 'swap' | 'sell' | 'send' | 'bridge';
const meta: Record<Tab, { title: string; sub: string }> = {
  swap: { title: 'Swap', sub: 'Exchange one token for another with wallet approval.' },
  sell: { title: 'Sell', sub: 'Sell a token for USDC with wallet approval.' },
  send: { title: 'Send', sub: 'Send tokens to another wallet address.' },
  bridge: { title: 'Bridge', sub: 'Move tokens from one network to another.' },
};
const useDebounced = <T,>(v: T, ms = 400) => { const [d, setD] = useState(v); useEffect(() => { const t = setTimeout(() => setD(v), ms); return () => clearTimeout(t); }, [v, ms]); return d; };
const Field = ({ label, children }: { label: string; children: React.ReactNode }) => <label className="field"><span>{label}</span>{children}</label>;

function NeedWallet() {
  return <div className="doc-note warn">Connect a wallet first. Every action here is reviewed and approved in your connected wallet. <button className="suggestion" onClick={openWalletMenu}>Connect wallet</button></div>;
}

function Send() {
  const { address } = useWallet(); const acct = useRialoAccount(address);
  const [to, setTo] = useState(''); const [amt, setAmt] = useState(''); const [open, setOpen] = useState(false);
  const kelvin = rloToKelvin(amt.trim());
  const bal = acct.data?.balanceKelvin;
  const err = !to ? '' : !isValidAddress(to) ? 'Enter a valid public address.' : to === address ? 'That is your own address.' : '';
  const amtErr = !amt ? '' : !kelvin ? 'Enter an amount with up to 9 decimal places.' : kelvin === '0' ? 'Amount must be greater than zero.' : bal && BigInt(kelvin) > BigInt(bal) ? 'More than your balance.' : '';
  const ok = Boolean(address) && isValidAddress(to) && !err && kelvin && kelvin !== '0' && !amtErr;
  const intent: TxIntent | null = ok ? { kind: 'send', to, amountRlo: amt.trim(), amountKelvin: kelvin! } : null;
  return <div className="panel trade-panel">
    {!address && <NeedWallet/>}
    <ActivationBanner kind="send"/>
    <Field label="Recipient address"><input className="wallet-input" value={to} onChange={e => setTo(e.target.value.trim())} placeholder="Public address" spellCheck={false}/></Field>
    {err && <div className="error-box">{err}</div>}
    <Field label="Amount (RLO)"><input className="wallet-input" inputMode="decimal" value={amt} onChange={e => setAmt(e.target.value.trim())} placeholder="0.0"/></Field>
    {amtErr && <div className="error-box">{amtErr}</div>}
    <div className="wallet-row"><span>Your balance</span><b>{acct.data?.balanceRlo != null ? `${acct.data.balanceRlo} RLO` : 'Unavailable until Rialo is live'}</b></div>
    <div className="wallet-row"><span>Network fee</span><b>Shown by your wallet</b></div>
    <button className="primary-button" disabled={!intent} onClick={() => setOpen(true)}>Review send <ArrowUpRight size={15}/></button>
    {open && intent && intent.kind === 'send' && <ApprovalDialog intent={intent} onClose={() => setOpen(false)} lines={[['To', intent.to], ['Amount', `${intent.amountRlo} RLO`], ['In kelvin', intent.amountKelvin], ['Network', 'Rialo']]}/>}
  </div>;
}

function Swap({ mode }: { mode: 'swap' | 'sell' }) {
  const sell = mode === 'sell';
  const { address } = useWallet(); const { data: m } = useMarkets();
  const all = m?.assets.map(a => a.symbol) ?? ['BTC', 'ETH', 'SOL', 'USDC'];
  const symbols = sell ? all.filter(x => x !== 'USDC') : all;
  const [from, setFrom] = useState('ETH'); const [toSel, setTo] = useState('USDC'); const to = sell ? 'USDC' : toSel; const [amt, setAmt] = useState(''); const [slip, setSlip] = useState(0.5); const [open, setOpen] = useState(false);
  const d = useDebounced(amt); const valid = Number(d) > 0 && from !== to;
  const q = useQuery({ queryKey: ['quote', from, to, d], enabled: valid, retry: false, queryFn: () => api<{ rate: number; estimatedReceive: number; fetchedAt: string; note: string }>(`/trade/quote?from=${from}&to=${to}&amount=${encodeURIComponent(d)}`) });
  const min = q.data ? q.data.estimatedReceive * (1 - slip / 100) : null;
  const intent: TxIntent | null = address && q.data && min != null ? (sell ? { kind: 'sell', asset: from, amount: d, receive: 'USDC', minReceive: min.toPrecision(8), slippagePct: slip } : { kind: 'swap', from, to, amountIn: d, minReceive: min.toPrecision(8), slippagePct: slip }) : null;
  const fmt = (n: number) => n.toLocaleString('en-US', { maximumSignificantDigits: 8 });
  return <div className="panel trade-panel">
    {!address && <NeedWallet/>}
    <ActivationBanner kind={sell ? 'sell' : 'swap'}/>
    <div className="field-row"><Field label={sell ? 'You sell' : 'You pay'}><input className="wallet-input" inputMode="decimal" value={amt} onChange={e => setAmt(e.target.value.trim())} placeholder="0.0"/></Field>
      <Field label="Token"><select className="wallet-input" value={from} onChange={e => setFrom(e.target.value)}>{symbols.map(s => <option key={s}>{s}</option>)}</select></Field></div>
    {!sell && <button className="suggestion" style={{ alignSelf: 'center' }} onClick={() => { setFrom(to); setTo(from); }} aria-label="Switch tokens"><ArrowDownUp size={14}/> Switch</button>}
    <div className="field-row"><Field label="You receive (estimate)"><input className="wallet-input" readOnly value={q.data ? fmt(q.data.estimatedReceive) : ''} placeholder="—"/></Field>
      <Field label="Token">{sell ? <input className="wallet-input" readOnly value="USDC"/> : <select className="wallet-input" value={to} onChange={e => setTo(e.target.value)}>{symbols.map(s => <option key={s}>{s}</option>)}</select>}</Field></div>
    <Field label="Slippage tolerance"><select className="wallet-input" value={slip} onChange={e => setSlip(Number(e.target.value))}>{[0.5, 1, 3].map(s => <option key={s} value={s}>{s}%</option>)}</select></Field>
    {from === to && <div className="error-box">Choose two different tokens.</div>}
    {q.isError && <div className="error-box">{q.error instanceof Error ? q.error.message : 'Quote unavailable.'}</div>}
    {q.data && <><div className="wallet-row"><span>Rate</span><b>1 {from} ≈ {fmt(q.data.rate)} {to}</b></div><div className="wallet-row"><span>Minimum received</span><b>{min != null ? fmt(min) : '—'} {to}</b></div><small className="doc-p">{q.data.note}</small></>}
    <button className="primary-button" disabled={!intent} onClick={() => setOpen(true)}>{sell ? 'Review sale' : 'Review swap'} <ArrowUpRight size={15}/></button>
    {open && intent && intent.kind === 'sell' && <ApprovalDialog intent={intent} onClose={() => setOpen(false)} lines={[['Sell', `${intent.amount} ${intent.asset}`], ['Receive at least', `${intent.minReceive} ${intent.receive}`], ['Slippage', `${intent.slippagePct}%`], ['Quote type', 'Indicative reference price']]}/>}
    {open && intent && intent.kind === 'swap' && <ApprovalDialog intent={intent} onClose={() => setOpen(false)} lines={[['Pay', `${intent.amountIn} ${intent.from}`], ['Receive at least', `${intent.minReceive} ${intent.to}`], ['Slippage', `${intent.slippagePct}%`], ['Quote type', 'Indicative reference price']]}/>}
  </div>;
}

const NETWORKS = ['Rialo', 'Ethereum', 'Solana', 'Bitcoin', 'Base', 'Arbitrum'];
function Bridge() {
  const { address } = useWallet();
  const [fromNet, setFromNet] = useState('Rialo'); const [toNet, setToNet] = useState('Ethereum'); const [asset, setAsset] = useState('USDC'); const [amt, setAmt] = useState(''); const [dest, setDest] = useState(''); const [open, setOpen] = useState(false);
  const ok = Boolean(address) && fromNet !== toNet && Number(amt) > 0 && dest.trim().length >= 20;
  const intent: TxIntent | null = ok ? { kind: 'bridge', asset, amount: amt, fromNetwork: fromNet, toNetwork: toNet, destination: dest.trim() } : null;
  return <div className="panel trade-panel">
    {!address && <NeedWallet/>}
    <ActivationBanner kind="bridge"/>
    <div className="field-row"><Field label="From network"><select className="wallet-input" value={fromNet} onChange={e => setFromNet(e.target.value)}>{NETWORKS.map(n => <option key={n}>{n}</option>)}</select></Field>
      <Field label="To network"><select className="wallet-input" value={toNet} onChange={e => setToNet(e.target.value)}>{NETWORKS.map(n => <option key={n}>{n}</option>)}</select></Field></div>
    <div className="field-row"><Field label="Amount"><input className="wallet-input" inputMode="decimal" value={amt} onChange={e => setAmt(e.target.value.trim())} placeholder="0.0"/></Field>
      <Field label="Token"><select className="wallet-input" value={asset} onChange={e => setAsset(e.target.value)}>{['USDC', 'RLO', 'ETH', 'BTC', 'SOL'].map(s => <option key={s}>{s}</option>)}</select></Field></div>
    <Field label="Destination address"><input className="wallet-input" value={dest} onChange={e => setDest(e.target.value)} placeholder="Address on the destination network" spellCheck={false}/></Field>
    {fromNet === toNet && <div className="error-box">Choose two different networks.</div>}
    <div className="wallet-row"><span>Route, fee and time</span><b>Needs a bridge provider</b></div>
    <button className="primary-button" disabled={!intent} onClick={() => setOpen(true)}>Review bridge <ArrowUpRight size={15}/></button>
    {open && intent && intent.kind === 'bridge' && <ApprovalDialog intent={intent} onClose={() => setOpen(false)} lines={[['Move', `${intent.amount} ${intent.asset}`], ['From', intent.fromNetwork], ['To', intent.toNetwork], ['Destination', intent.destination]]}/>}
  </div>;
}

export default function Trade({ tab }: { tab: Tab }) {
  const m = meta[tab];
  return <div className="page-content"><SectionTitle title={m.title} subtitle={m.sub}/>
    <div className="doc-note safe" style={{ marginBottom: 14 }}>Every transaction is approved and signed in your connected wallet. PaydFinance never holds keys and the server never signs.</div>
    <div style={{ maxWidth: 560 }}>{tab === 'swap' || tab === 'sell' ? <Swap mode={tab}/> : tab === 'send' ? <Send/> : <Bridge/>}</div>
  </div>;
}
