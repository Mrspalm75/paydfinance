export type ModuleKey =
  | 'dashboard' | 'ai-mentor' | 'markets' | 'analyzer' | 'portfolio'
  | 'finance' | 'automation' | 'risk' | 'news' | 'transactions'
  | 'watchlist' | 'reports' | 'notifications' | 'settings';

export interface ChatMessage { role: 'user' | 'assistant'; content: string; }
