# Deploy PaydFinance to Vercel

One Vercel project serves both the website (`client/dist`) and the API (`/api/*`, the Express app run as a serverless function).

## Steps
1. Push this folder to a GitHub repository (the `paydfinance` folder is the repo root).
2. In Vercel: **Add New, Project**, import the repository. Leave the framework preset as "Other". `vercel.json` already sets the install command, build command (`npm run build`) and output directory (`client/dist`).
3. Add environment variables (Project Settings, Environment Variables). All are optional; features turn off cleanly without them:

| Variable | Purpose |
|---|---|
| `OPENAI_API_KEY` | AI Mentor and chart reading |
| `MARKET_DATA_API_KEY` | Optional CoinGecko demo key for higher rate limits |
| `FRED_API_KEY` | US economic indicators on the Economic Data page |
| `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY` | Persistence and auth, if you use Supabase |
| `RIALO_ENABLED`, `RIALO_RPC_URL`, `RIALO_NETWORK`, `RIALO_CHAIN_ID` | Set when Rialo is live. Values come from the official docs |

   `VITE_API_BASE_URL` is not needed: in production the site calls `/api` on the same domain.
4. Click **Deploy**. Open `https://<your-project>.vercel.app/api/health` to confirm the API, then the site.

CLI alternative: `npm i -g vercel`, then `vercel` and `vercel --prod` from this folder.

## Notes
- The first deploy runs a TypeScript check. This code was written without a local type check, so the first build may report errors. Fix them from the build log, or ask for help with the log.
- Vercel serverless requests are limited to about 4.5 MB. Chart uploads are shrunk in the browser first, so normal screenshots fit.
- In-memory market caches and rate limits are per serverless instance, which is fine for this app. For heavy traffic, add a shared store (for example Vercel KV).
- Never put `OPENAI_API_KEY` or other secrets in `VITE_*` variables. Those are public.
