# Implementation status

## Implemented in this starter
- Responsive React dashboard shell and 14 navigable routes.
- All 12 requested product modules represented in the UI.
- AI chat endpoint with OpenAI adapter and provider interface.
- Express security baseline: Helmet, CORS allowlist, JSON body limit, rate limits.
- Supabase browser client and starter schema with RLS.
- API health, AI, market status, portfolio status, alerts and automation endpoints.
- Read-only Rialo adapter (JSON-RPC health, balance, account info) that stays unavailable until RIALO_RPC_URL is configured; UI status in sidebar and Portfolio lookup. Untested against a live node.


- Live market prices, 24h change, market cap, volume and price charts via CoinGecko (server-cached; optional MARKET_DATA_API_KEY).

## Demo / placeholder only
- Recent activity.
- Portfolio and transaction UI data.
- Alert persistence and notification delivery.
- Automation execution.
- Risk calculations, financial records and reports.
- Wallet integration and onchain transaction reading.

## Not implemented / requires verified third-party access
- Rialo contract calls, transaction submission and wallet signing; live-node verification of the read-only calls.
- Live market data and financial news provider.
- Production Supabase JWT verification on private API routes.
- Production user onboarding, password recovery and MFA UI.
- Real portfolio valuation, P&L and technical indicator calculations.
- Email and push notification delivery.
- Executable trades, transfers, payments or recurring transactions.

Do not advertise placeholder features as live functionality. Do not connect real funds until wallet signing, transaction simulation, authorization, monitoring and independent security review are complete.
