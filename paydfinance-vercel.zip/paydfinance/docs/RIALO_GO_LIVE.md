# Rialo go-live: Swap, Sell, Bridge and Send

The Trade pages are finished and waiting. Each page shows a "Waiting for Rialo" banner and re-checks every 30 seconds, so it switches on by itself when all of these are true.

| Feature | Needs |
|---|---|
| Send | Rialo node reachable, signing wallet adapter |
| Swap, Sell | Node reachable, `RIALO_SWAP_ENABLED=true`, swap venue implemented, wallet adapter supporting `swap` / `sell` |
| Bridge | Node reachable, `RIALO_BRIDGE_ENABLED=true`, bridge provider implemented, wallet adapter supporting `bridge` |

## Steps when Rialo is live
1. Take the RPC URL, network and chain ID from the official docs. Set `RIALO_ENABLED`, `RIALO_RPC_URL`, `RIALO_NETWORK`, `RIALO_CHAIN_ID` in `server/.env`. Check `GET /api/rialo/readiness`.
2. Copy `client/src/lib/rialoWalletAdapter.template.ts` to `rialoWalletAdapter.ts`, implement it from the official wallet docs, and register it in `adapters` (`walletAdapter.ts`). Send turns on.
3. Swap and Sell: implement the venue in `server/src/routes/trade.ts` (replace the CoinGecko reference quote with the venue's quote), add `swap` and `sell` to the adapter's `supports`, set `RIALO_SWAP_ENABLED=true`.
4. Bridge: add a provider (routes, quote, status), add `bridge` to `supports`, set `RIALO_BRIDGE_ENABLED=true`.
5. Test every flow on devnet with small amounts before mainnet. Add tests for amount parsing (`rloToKelvin`), address validation and the readiness gate.

The server never signs and never holds keys. Every transaction goes through `adapter.approveAndSend`, which must show the wallet's own permission prompt.
