# Rialo integration guide

This guide tells developers where the official Rialo documentation lives and how this project connects to it. It links to the official sources instead of copying them, so you always read the current version.

## Official resources

| Resource | URL |
| --- | --- |
| Documentation | https://www.rialo.io/docs (also https://docs.rialo.io) |
| Developer portal | https://www.rialo.io/for-devs |
| Learn | https://learn.rialo.io |
| Playground | https://playground.rialo.io |
| Blog and announcements | https://www.rialo.io/blog |
| GitHub organisation | https://github.com/rialo |
| X (official) | https://x.com/RialoHQ |
| Discord / Telegram | https://discord.gg/RialoProtocol · https://t.me/rialoprotocol |
| Client SDK source (`rialo-cdk`, Rust) | https://docs.rs/crate/rialo-cdk/latest |
| Python client (`rialo-py-cdk`) | https://pypi.org/project/rialo-py-cdk/ |

Notes on sources:
- The documentation site could not be read by automated tooling when this guide was written, so the technical details below come from the published `rialo-cdk` client source and the public site. Confirm each one against the docs.
- The crate named `rialo` on crates.io is an unrelated placeholder. Use `rialo-cdk`.
- As of this writing the public site does not state a mainnet launch or give public RPC endpoints. Do not assume any.

## What this project implements

| Piece | Location |
| --- | --- |
| Read-only adapter | `server/src/integrations/rialo/RialoAdapter.ts` |
| Routes | `server/src/routes/rialo.ts`, `server/src/routes/health.ts` (`/api/health/rialo`) |
| Config | `RIALO_ENABLED`, `RIALO_RPC_URL`, `RIALO_NETWORK`, `RIALO_CHAIN_ID` in `server/.env` |
| UI status | sidebar card, Portfolio account lookup (`client/src/lib/useRialoStatus.ts`) |

Endpoints:

- `GET /api/rialo/status` — configured, reachable, mode (`read-only`).
- `GET /api/rialo/account/:address` — raw balance in kelvin from `getBalance`, plus account info.
- `POST /api/rialo/transactions` — always 501. Signing happens in the user's wallet, never on the server.

Until `RIALO_ENABLED=true` and `RIALO_RPC_URL` are set, the app reports "Awaiting mainnet" and makes no network calls.

## RPC methods used

The adapter speaks HTTP JSON-RPC (POST). Method names come from `rialo-cdk` (older published version, so verify):

| Method | Used for |
| --- | --- |
| `getHealth` | status check |
| `getBalance` | account balance (kelvin; no RLO conversion is applied) |
| `getAccountInfo` | account data (base64) |

Other methods seen in the client source that you may want later: `getTransaction`, `getSignatureStatuses`, `getSignaturesForAddress`, `getMultipleAccounts`, `getAccountsByOwner`, `getEpochInfo`, `getBlockHeight`. Network names seen in the client constants: `devnet`, `testnet`, `mainnet`, `localnet`.

Unverified, so deliberately not assumed: public RPC URLs, chain ID, the exact `jsonrpc` version string, response shapes on a live node, and the kelvin to RLO conversion.

## Go-live checklist

1. Read the official docs and confirm the network name, RPC endpoint and chain ID.
2. Put them in `server/.env`: `RIALO_ENABLED=true`, `RIALO_RPC_URL`, `RIALO_NETWORK`, `RIALO_CHAIN_ID`.
3. Start the API and open `/api/rialo/status`. It should return `reachable: true`.
4. Call `/api/rialo/account/<public address>` with a known address and compare with the official explorer.
5. Confirm the response shapes and the kelvin conversion, then add the conversion in the adapter.
6. Add integration tests against the supported development network.
7. Only then build wallet-signed writes (see below).

## Adding a read method

1. Add a method to `RialoAdapter` that calls `this.rpc('<methodName>', <params>)` with the params shape from the docs.
2. Expose it in `server/src/routes/rialo.ts` with input validation.
3. Add a typed hook in `client/src/lib/` and use it in a page.

## Writes and wallets

- Never collect seed phrases or private keys, and never sign on the server.
- Use the wallet or signer the official docs recommend. Build the transaction client-side, have the user sign, then submit through the documented method.
- Simulate before sending where the docs support it, show the fee, and require an explicit confirmation.
- Keep `submitUserAuthorizedAction` disabled until all of the above is implemented and reviewed.

## Troubleshooting

| Symptom | Likely cause |
| --- | --- |
| "Awaiting mainnet" in the sidebar | `RIALO_ENABLED` is not `true` or `RIALO_RPC_URL` is empty |
| `Rialo node is unreachable or timed out` | wrong URL, node down, or outbound network blocked |
| `Rialo RPC error ...` | method name or params differ from the node's version; check the docs |
| Balance looks 1000s of times too big or small | value is raw kelvin; conversion not applied yet |
