export interface AIRequest { message: string; context?: Record<string, unknown>; }
export interface ChartAnalysisRequest { imageDataUrl: string; question?: string; }
export interface AIProvider { readonly name: string; generate(input: AIRequest): Promise<string>; analyzeChart?(input: ChartAnalysisRequest): Promise<string>; }
