import type { AIProvider } from './AIProvider.js';
import { OpenAIProvider } from './providers/OpenAIProvider.js';
import { env } from '../config/env.js';

export function createAIProvider(): AIProvider {
  switch (env.aiProvider) {
    case 'openai': return new OpenAIProvider(env.openaiApiKey, env.openaiModel);
    // Add additional providers here by implementing AIProvider.
    default: throw new Error(`Unsupported AI provider "${env.aiProvider}". Implement and register its adapter first.`);
  }
}
