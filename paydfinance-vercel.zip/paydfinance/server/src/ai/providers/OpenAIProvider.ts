import OpenAI from 'openai';
import type { AIProvider, AIRequest, ChartAnalysisRequest } from '../AIProvider.js';

export class OpenAIProvider implements AIProvider {
  readonly name = 'openai';
  private client: OpenAI;
  constructor(apiKey: string, private model: string) {
    if (!apiKey) throw new Error('OPENAI_API_KEY is not configured on the server.');
    this.client = new OpenAI({ apiKey });
  }
  async generate(input: AIRequest): Promise<string> {
    const response = await this.client.chat.completions.create({
      model: this.model,
      temperature: 0.25,
      messages: [
        { role: 'system', content: 'You are PaydFinance AI, an educational financial information assistant. Be clear, cautious and transparent. Never claim to have live prices, wallet balances or news unless they are provided in the supplied context. Do not guarantee returns or present personalized investment instructions. Explain uncertainty and encourage independent verification. Never request seed phrases, private keys or passwords.' },
        { role: 'user', content: JSON.stringify({ question: input.message, verifiedContext: input.context || {} }) }
      ]
    });
    return response.choices[0]?.message?.content || 'I could not generate a response. Please try again.';
  }

  async analyzeChart(input: ChartAnalysisRequest): Promise<string> {
    const response = await this.client.chat.completions.create({
      model: this.model,
      temperature: 0.2,
      messages: [
        { role: 'system', content: 'You are PaydFinance AI, an educational chart-reading assistant. The user uploads a screenshot of a price chart. Describe only what is visible: asset and timeframe if labelled, overall trend, notable highs/lows, visible support and resistance zones, candlestick or chart patterns, and any indicators shown (moving averages, RSI, MACD, volume). Say clearly what you cannot tell from the image. If the image is not a financial chart, say so. Never give buy, sell or price-target instructions and never guarantee outcomes. Mention that a screenshot is not live data and the analysis is educational, not investment advice. Use short sections with plain text.' },
        { role: 'user', content: [
          { type: 'text', text: input.question?.trim() || 'Explain what this chart shows and what a careful reader should look at next.' },
          { type: 'image_url', image_url: { url: input.imageDataUrl } },
        ] },
      ],
    });
    return response.choices[0]?.message?.content || 'I could not analyse this chart. Please try another image.';
  }
}
