import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { env } from './config/env.js';
import healthRoutes from './routes/health.js';
import aiRoutes from './routes/ai.js';
import marketRoutes from './routes/markets.js';
import portfolioRoutes from './routes/portfolio.js';
import alertRoutes from './routes/alerts.js';
import automationRoutes from './routes/automation.js';
import rialoRoutes from './routes/rialo.js';
import tradeRoutes from './routes/trade.js';
import economyRoutes from './routes/economy.js';
import { errorHandler } from './middleware/errorHandler.js';

const app = express();
app.set('trust proxy', 1); // behind Vercel/other proxies, so rate limiting sees the real client IP
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: env.clientOrigin.split(',').map(v => v.trim()), credentials: true }));
// Chart uploads arrive as base64 images, so this one route needs a larger body limit (registered before the global parser).
app.use('/api/ai/analyze-chart', express.json({ limit: '8mb' }));
app.use(express.json({ limit: '32kb' }));
app.use('/api', rateLimit({ windowMs: 60_000, limit: 100, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/api/health', healthRoutes);
app.use('/api/ai', rateLimit({ windowMs: 60_000, limit: 12, standardHeaders: true, legacyHeaders: false }), aiRoutes);
app.use('/api/markets', marketRoutes);
app.use('/api/portfolio', portfolioRoutes);
app.use('/api/alerts', alertRoutes);
app.use('/api/automation', automationRoutes);
app.use('/api/rialo', rialoRoutes);
app.use('/api/trade', tradeRoutes);
app.use('/api/economy', economyRoutes);
app.use((_req,res) => res.status(404).json({ error: 'Route not found.' }));
app.use(errorHandler);

export default app;
