import { env } from '../../config/env.js';

export type RialoStatus = {
  configured: boolean;
  reachable: boolean | null;
  network: string | null;
  chainId: string | null;
  mode: 'unavailable' | 'read-only';
  writesEnabled: false;
  message: string;
};

export type RialoAccountOverview = {
  address: string;
  /** Raw balance in kelvin as returned by the node's getBalance. Not converted. */
  balanceKelvin: string | null;
  /** balanceKelvin / 1,000,000,000 (1 RLO = 1e9 kelvin per rialo-cdk). */
  balanceRlo: string | null;
  accountInfo: unknown | null;
  fetchedAt: string;
  source: 'rialo-rpc';
};

export function kelvinToRlo(kelvin: string): string {
  const k = BigInt(kelvin); const whole = k / 1_000_000_000n;
  const frac = (k % 1_000_000_000n).toString().padStart(9, '0').replace(/0+$/, '');
  return frac ? `${whole}.${frac}` : whole.toString();
}

export class RialoError extends Error {
  constructor(message: string, readonly status = 502) { super(message); }
}

/**
 * Read-only Rialo adapter over the node's HTTP JSON-RPC interface.
 *
 * Method names used (getHealth, getBalance, getAccountInfo) come from the
 * published rialo-cdk client source (docs.rs/crate/rialo-cdk). The RPC URL,
 * network name and chain ID are NOT assumed: they must be supplied through
 * RIALO_RPC_URL / RIALO_NETWORK / RIALO_CHAIN_ID from official Rialo docs.
 *
 * Transaction submission is intentionally unsupported. Signing must happen in
 * a user-controlled wallet; the server never holds keys.
 */
export class RialoAdapter {
  private nextId = 1;

  private get configured() { return env.rialoEnabled && Boolean(env.rialoRpcUrl); }

  private async rpc<T>(method: string, params: unknown): Promise<T> {
    if (!this.configured) throw new RialoError('Rialo is not configured. Set RIALO_ENABLED=true and RIALO_RPC_URL.', 503);
    let res: Response;
    try {
      res = await fetch(env.rialoRpcUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: this.nextId++, method, params }),
        signal: AbortSignal.timeout(8000),
      });
    } catch {
      throw new RialoError('Rialo node is unreachable or timed out.', 504);
    }
    if (!res.ok) throw new RialoError(`Rialo node returned HTTP ${res.status}.`);
    const body = await res.json().catch(() => null) as { result?: T; error?: { code: number; message: string } } | null;
    if (!body) throw new RialoError('Rialo node returned an invalid response.');
    if (body.error) throw new RialoError(`Rialo RPC error ${body.error.code}: ${body.error.message}`);
    if (body.result === undefined) throw new RialoError('Rialo RPC response had no result.');
    return body.result;
  }

  async status(): Promise<RialoStatus> {
    const base = {
      network: env.rialoNetwork || null,
      chainId: env.rialoChainId || null,
      writesEnabled: false as const,
    };
    if (!this.configured) {
      return { ...base, configured: false, reachable: null, mode: 'unavailable',
        message: 'Rialo is not configured. Set RIALO_ENABLED=true and RIALO_RPC_URL from official Rialo documentation.' };
    }
    try {
      await this.rpc('getHealth', [{}]);
      return { ...base, configured: true, reachable: true, mode: 'read-only', message: 'Connected to Rialo node (read-only).' };
    } catch (e) {
      return { ...base, configured: true, reachable: false, mode: 'read-only',
        message: e instanceof Error ? e.message : 'Rialo node check failed.' };
    }
  }

  async getAccountOverview(address: string): Promise<RialoAccountOverview> {
    const [balance, info] = await Promise.all([
      this.rpc<{ value?: number | string }>('getBalance', [{ pubkey: address }]),
      this.rpc<{ value?: unknown }>('getAccountInfo', [{ address, config: { encoding: 'base64' } }]),
    ]);
    return {
      address,
      balanceKelvin: balance.value === undefined ? null : String(balance.value),
      balanceRlo: balance.value === undefined || !/^\d+$/.test(String(balance.value)) ? null : kelvinToRlo(String(balance.value)),
      accountInfo: info.value ?? null,
      fetchedAt: new Date().toISOString(),
      source: 'rialo-rpc',
    };
  }

  async submitUserAuthorizedAction(_payload: unknown): Promise<never> {
    throw new RialoError('Transaction submission is disabled. Sign transactions in a user-controlled wallet.', 501);
  }
}

export const rialo = new RialoAdapter();
