/**
 * Go-live plug points for trading on Rialo.
 *
 * Nothing here talks to a network until a venue or provider is registered. Once Rialo publishes official
 * swap and bridge details, implement these interfaces, call register* from `registerVenues()` below, and the
 * Swap, Sell and Bridge pages switch from "waiting" to "ready" automatically (see GET /api/trade/capabilities).
 * Implementations must only quote and build requests. Signing always happens in the user's wallet.
 */
export interface SwapQuote { rate: number; estimatedReceive: number; feeText?: string; priceImpactPct?: number; expiresAt?: string; note?: string; }
export interface SwapVenue { id: string; name: string; quote(req: { from: string; to: string; amount: number }): Promise<SwapQuote>; tokens(): Promise<string[]>; }

export interface BridgeRoute { fromNetwork: string; toNetwork: string; asset: string; }
export interface BridgeQuote { receiveAmount: string; feeText: string; etaMinutes: number; expiresAt?: string; }
export interface BridgeProvider { id: string; name: string; routes(): Promise<BridgeRoute[]>; quote(req: BridgeRoute & { amount: string }): Promise<BridgeQuote>; }

let swapVenue: SwapVenue | null = null;
let bridgeProvider: BridgeProvider | null = null;
export const registerSwapVenue = (v: SwapVenue) => { swapVenue = v; };
export const registerBridgeProvider = (p: BridgeProvider) => { bridgeProvider = p; };
export const getSwapVenue = () => swapVenue;
export const getBridgeProvider = () => bridgeProvider;

/** Add `registerSwapVenue(new MyRialoDex())` and `registerBridgeProvider(new MyBridge())` here when verified. */
export function registerVenues() { /* none verified yet */ }
registerVenues();
