import type { ErrorRequestHandler } from 'express';
export const errorHandler: ErrorRequestHandler = (err, _req, res, _next) => {
  console.error('[api-error]', err);
  res.status(500).json({ error: 'An unexpected server error occurred.' });
};
