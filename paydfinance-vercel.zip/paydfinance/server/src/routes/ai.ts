import { Router } from 'express';
import { z } from 'zod';
import { env } from '../config/env.js';
import { createAIProvider } from '../ai/providerFactory.js';
const router = Router();
const schema = z.object({ message: z.string().trim().min(2).max(4000), context: z.record(z.unknown()).optional() });
router.get('/status', (_req,res) => res.json({
  provider: env.aiProvider,
  configured: env.aiProvider === 'openai' && Boolean(env.openaiApiKey),
  model: env.aiProvider === 'openai' ? env.openaiModel : null,
}));
router.post('/chat', async (req,res,next) => {
  try {
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Please provide a message between 2 and 4000 characters.' });
    const provider = createAIProvider();
    const answer = await provider.generate(parsed.data);
    res.json({ answer, provider: provider.name, disclaimer: 'Informational only; not personalized investment advice.' });
  } catch (error) { next(error); }
});

const chartSchema = z.object({
  image: z.string().max(7_000_000).regex(/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/, 'Upload a PNG, JPEG or WebP image.'),
  question: z.string().trim().max(1000).optional(),
});
router.post('/analyze-chart', async (req,res,next) => {
  try {
    const parsed = chartSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0]?.message || 'Upload a PNG, JPEG or WebP chart image under 5 MB.' });
    const provider = createAIProvider();
    if (!provider.analyzeChart) return res.status(501).json({ error: `Provider "${provider.name}" does not support image analysis.` });
    const answer = await provider.analyzeChart({ imageDataUrl: parsed.data.image, question: parsed.data.question });
    res.json({ answer, provider: provider.name, disclaimer: 'Educational chart reading from a screenshot; not investment advice.' });
  } catch (error) { next(error); }
});
export default router;
