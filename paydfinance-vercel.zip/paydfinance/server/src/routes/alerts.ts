import { Router } from 'express';
import { z } from 'zod';
const router = Router();
const schema = z.object({ symbol: z.string().min(2).max(16), targetPrice: z.number().positive(), direction: z.enum(['above','below']) });
router.post('/', (req,res) => {
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid alert details.' });
  res.status(501).json({ error: 'Alert persistence and delivery are not configured yet.', acceptedInput: parsed.data });
});
router.get('/', (_req,res) => res.json({ alerts: [], configured: false }));
export default router;
