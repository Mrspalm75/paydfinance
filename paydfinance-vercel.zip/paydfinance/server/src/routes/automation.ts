import { Router } from 'express';
const router = Router();
router.get('/', (_req,res) => res.json({ rules: [], executionEnabled: false, message: 'Automation is preview-only. No trades or transfers can be executed.' }));
router.post('/', (_req,res) => res.status(501).json({ error: 'Persisted automation rules are not configured. No action was executed.' }));
export default router;
