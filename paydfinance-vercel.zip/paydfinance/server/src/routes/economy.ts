import { Router } from 'express';
import { env } from '../config/env.js';
import { cached, getJson } from './markets.js';
const router = Router();

const SERIES = [
  { id: 'FEDFUNDS', label: 'Federal funds rate', unit: '%', kind: 'level' },
  { id: 'CPIAUCSL', label: 'Inflation (CPI, year over year)', unit: '%', kind: 'yoy' },
  { id: 'UNRATE', label: 'Unemployment rate', unit: '%', kind: 'level' },
  { id: 'DGS10', label: '10-year Treasury yield', unit: '%', kind: 'level' },
  { id: 'T10Y2Y', label: '10-year minus 2-year Treasury spread', unit: 'pp', kind: 'level' },
  { id: 'A191RL1Q225SBEA', label: 'Real GDP growth (quarterly, annualized)', unit: '%', kind: 'level' },
] as const;

type Obs = { date: string; value: string };
async function fred(id: string): Promise<Obs[]> {
  const url = `https://api.stlouisfed.org/fred/series/observations?series_id=${id}&api_key=${encodeURIComponent(env.fredApiKey)}&file_type=json&sort_order=desc&limit=16`;
  const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new Error(`FRED returned HTTP ${res.status} for ${id}.`);
  const body = await res.json() as { observations?: Obs[] };
  return (body.observations ?? []).filter(o => o.value !== '.');
}

router.get('/overview', async (_req, res) => {
  // Global crypto market context needs no key.
  let crypto: unknown = null;
  try {
    const g = await cached('global', 60_000, () => getJson<{ data: { total_market_cap: { usd: number }; total_volume: { usd: number }; market_cap_percentage: { btc: number; eth: number }; market_cap_change_percentage_24h_usd: number } }>('/global'));
    crypto = { totalMarketCapUsd: g.data.total_market_cap.usd, volume24hUsd: g.data.total_volume.usd, btcDominance: g.data.market_cap_percentage.btc, ethDominance: g.data.market_cap_percentage.eth, change24h: g.data.market_cap_change_percentage_24h_usd, source: 'CoinGecko' };
  } catch { crypto = null; }

  if (!env.fredApiKey) return res.json({ macro: { configured: false, message: 'Set FRED_API_KEY (free from fred.stlouisfed.org) to show US economic indicators.', indicators: [] }, crypto, fetchedAt: new Date().toISOString() });
  try {
    const indicators = await cached('macro', 60 * 60_000, () => Promise.all(SERIES.map(async s => {
      const o = await fred(s.id);
      if (!o.length) return { ...s, value: null, previous: null, date: null };
      const num = (i: number) => Number(o[i]?.value);
      if (s.kind === 'yoy') {
        const v = o.length > 12 ? (num(0) / num(12) - 1) * 100 : null; const p = o.length > 13 ? (num(1) / num(13) - 1) * 100 : null;
        return { ...s, value: v, previous: p, date: o[0].date };
      }
      return { ...s, value: num(0), previous: o.length > 1 ? num(1) : null, date: o[0].date };
    })));
    res.json({ macro: { configured: true, source: 'FRED, Federal Reserve Bank of St. Louis', indicators }, crypto, fetchedAt: new Date().toISOString() });
  } catch (e) { res.status(502).json({ error: e instanceof Error ? e.message : 'Economic data unavailable.', crypto }); }
});
export default router;
