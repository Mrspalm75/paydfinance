import { Router } from 'express';
import { rialo } from '../integrations/rialo/RialoAdapter.js';
const router = Router();
router.get('/', (_req,res) => res.json({ ok: true, service: 'paydfinance-api', timestamp: new Date().toISOString() }));
router.get('/rialo', async (_req,res,next) => { try { res.json(await rialo.status()); } catch (e) { next(e); } });
export default router;
