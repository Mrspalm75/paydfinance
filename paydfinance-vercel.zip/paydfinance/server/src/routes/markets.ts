import { Router } from 'express';
import { env } from '../config/env.js';
const router = Router();

const ASSETS = [
  { id: 'bitcoin', symbol: 'BTC', name: 'Bitcoin' },
  { id: 'ethereum', symbol: 'ETH', name: 'Ethereum' },
  { id: 'solana', symbol: 'SOL', name: 'Solana' },
  { id: 'usd-coin', symbol: 'USDC', name: 'USD Coin' },
];
const base = () => (env.marketDataBaseUrl || 'https://api.coingecko.com/api/v3').replace(/\/$/, '');
const headers = (): Record<string, string> => env.marketDataApiKey ? { 'x-cg-demo-api-key': env.marketDataApiKey, accept: 'application/json' } : { accept: 'application/json' };

// Small in-memory cache so the public API is not hit on every page view.
const cache = new Map<string, { at: number; data: unknown }>();
async function cached<T>(key: string, ttlMs: number, load: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.data as T;
  const data = await load();
  cache.set(key, { at: Date.now(), data });
  return data;
}
async function getJson<T>(path: string): Promise<T> {
  const res = await fetch(`${base()}${path}`, { headers: headers(), signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new Error(`Market data provider returned HTTP ${res.status}.`);
  return res.json() as Promise<T>;
}

export type OverviewAsset = { symbol: string; name: string; id: string; price: number | null; change24h: number | null; marketCap: number | null; volume24h: number | null; providerUpdatedAt: string | null };
export async function loadOverview(): Promise<OverviewAsset[]> {
  const ids = ASSETS.map(a => a.id).join(',');
  const data = await cached('overview', 30_000, () => getJson<Record<string, Record<string, number>>>(
    `/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true&include_market_cap=true&include_24hr_vol=true&include_last_updated_at=true`));
  return ASSETS.map(a => {
    const d = data[a.id] || {};
    return { symbol: a.symbol, name: a.name, id: a.id, price: d.usd ?? null, change24h: d.usd_24h_change ?? null,
      marketCap: d.usd_market_cap ?? null, volume24h: d.usd_24h_vol ?? null,
      providerUpdatedAt: d.last_updated_at ? new Date(d.last_updated_at * 1000).toISOString() : null };
  });
}
export { cached, getJson };

router.get('/overview', async (_req, res) => {
  try { res.json({ live: true, source: 'CoinGecko', currency: 'USD', fetchedAt: new Date().toISOString(), assets: await loadOverview() }); }
  catch (e) { res.status(502).json({ live: false, error: e instanceof Error ? e.message : 'Market data unavailable.' }); }
});

router.get('/chart', async (req, res) => {
  const asset = ASSETS.find(a => a.id === req.query.id) ?? ASSETS[0];
  const days = [1, 7, 30, 90].includes(Number(req.query.days)) ? Number(req.query.days) : 7;
  try {
    const data = await cached(`chart:${asset.id}:${days}`, 5 * 60_000, () => getJson<{ prices: [number, number][] }>(
      `/coins/${asset.id}/market_chart?vs_currency=usd&days=${days}`));
    res.json({ live: true, source: 'CoinGecko', currency: 'USD', id: asset.id, symbol: asset.symbol, days,
      points: data.prices.map(([t, p]) => ({ t, price: p })) });
  } catch (e) {
    res.status(502).json({ live: false, error: e instanceof Error ? e.message : 'Market data unavailable.' });
  }
});
export default router;
