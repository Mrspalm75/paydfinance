import { Router } from 'express';
const router = Router();
router.get('/', (_req,res) => res.json({
  connected: false,
  totalValue: null,
  assets: [],
  message: 'No wallet is connected. Connect a supported wallet before requesting portfolio data.'
}));
export default router;
