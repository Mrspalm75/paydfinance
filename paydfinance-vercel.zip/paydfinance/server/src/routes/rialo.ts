import { Router } from 'express';
import { env } from '../config/env.js';
import { getBridgeProvider, getSwapVenue } from '../integrations/rialo/venues.js';
import { rialo, RialoError } from '../integrations/rialo/RialoAdapter.js';
const router = Router();
router.get('/readiness', async (_req, res, next) => {
  try {
    const st = await rialo.status();
    const node = st.configured && st.reachable === true;
    const nodeReq = node ? [] : [st.configured ? 'Rialo node must be reachable' : 'Set RIALO_ENABLED=true and RIALO_RPC_URL'];
    const feature = (flag: boolean, name: string, hasVenue: boolean, venueName: string) => {
      const requires = [...nodeReq, ...(hasVenue ? [] : [`Register a ${venueName} in server/src/integrations/rialo/venues.ts`]), ...(flag ? [] : [`Set ${name}=true`])];
      return { ready: requires.length === 0, requires };
    };
    res.json({
      node: { configured: st.configured, reachable: st.reachable, network: st.network },
      features: {
        send: { ready: node, requires: nodeReq },
        swap: feature(env.rialoSwapEnabled, 'RIALO_SWAP_ENABLED', Boolean(getSwapVenue()), 'swap venue'),
        sell: feature(env.rialoSwapEnabled, 'RIALO_SWAP_ENABLED', Boolean(getSwapVenue()), 'swap venue'),
        bridge: feature(env.rialoBridgeEnabled, 'RIALO_BRIDGE_ENABLED', Boolean(getBridgeProvider()), 'bridge provider'),
      },
      checkedAt: new Date().toISOString(),
    });
  } catch (e) { next(e); }
});
router.get('/status', async (_req, res, next) => { try { res.json(await rialo.status()); } catch (e) { next(e); } });
router.get('/account/:address', async (req, res) => {
  const address = req.params.address;
  // Loose sanity check only; the node is the authority on address validity.
  if (!/^[A-Za-z0-9]{20,100}$/.test(address)) return res.status(400).json({ error: 'Invalid account address.' });
  try { res.json(await rialo.getAccountOverview(address)); }
  catch (e) { const s = e instanceof RialoError ? e.status : 500; res.status(s).json({ error: e instanceof Error ? e.message : 'Rialo request failed.' }); }
});
router.post('/transactions', (_req, res) => res.status(501).json({ error: 'Transaction submission is disabled. Sign in a user-controlled wallet.' }));
export default router;
