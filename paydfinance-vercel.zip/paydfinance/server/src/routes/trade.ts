import { Router } from 'express';
import { loadOverview } from './markets.js';
import { getBridgeProvider, getSwapVenue } from '../integrations/rialo/venues.js';
const router = Router();

/**
 * Indicative swap quote from live reference prices (no liquidity, fees, slippage or execution).
 * Real swaps need a Rialo DEX or aggregator; none is verified yet.
 */
router.get('/bridge/routes', async (_req, res) => {
  const b = getBridgeProvider();
  if (!b) return res.json({ provider: null, routes: [] });
  try { res.json({ provider: b.name, routes: await b.routes() }); } catch (e) { res.status(502).json({ error: e instanceof Error ? e.message : 'Routes unavailable.' }); }
});
router.get('/bridge/quote', async (req, res) => {
  const b = getBridgeProvider();
  if (!b) return res.status(501).json({ error: 'No bridge provider is connected yet.' });
  const { fromNetwork, toNetwork, asset, amount } = req.query as Record<string, string>;
  if (!fromNetwork || !toNetwork || !asset || !(Number(amount) > 0)) return res.status(400).json({ error: 'Provide fromNetwork, toNetwork, asset and a positive amount.' });
  try { res.json(await b.quote({ fromNetwork, toNetwork, asset, amount })); } catch (e) { res.status(502).json({ error: e instanceof Error ? e.message : 'Quote unavailable.' }); }
});

router.get('/quote', async (req, res) => {
  const from = String(req.query.from || '').toUpperCase(); const to = String(req.query.to || '').toUpperCase();
  const amount = Number(req.query.amount);
  if (!Number.isFinite(amount) || amount <= 0 || amount > 1e12) return res.status(400).json({ error: 'Enter an amount greater than zero.' });
  try {
    const venue = getSwapVenue();
    if (venue) { const q = await venue.quote({ from, to, amount }); return res.json({ from, to, amount, ...q, source: venue.name, fetchedAt: new Date().toISOString(), executable: true, note: q.note ?? q.feeText ?? '' }); }
    const assets = await loadOverview();
    const a = assets.find(x => x.symbol === from); const b = assets.find(x => x.symbol === to);
    if (!a || !b) return res.status(400).json({ error: 'Unsupported asset.' });
    if (a.symbol === b.symbol) return res.status(400).json({ error: 'Choose two different assets.' });
    if (!a.price || !b.price) return res.status(502).json({ error: 'Reference prices are unavailable right now.' });
    const rate = a.price / b.price;
    res.json({ from, to, amount, rate, estimatedReceive: amount * rate, fromUsd: a.price, toUsd: b.price,
      source: 'CoinGecko reference prices', fetchedAt: new Date().toISOString(), executable: false,
      note: 'Indicative only. Excludes fees, spread and slippage. No swap venue is connected.' });
  } catch (e) { res.status(502).json({ error: e instanceof Error ? e.message : 'Quote unavailable.' }); }
});

const notAvailable = (what: string) => (_req: unknown, res: { status: (n: number) => { json: (b: unknown) => void } }) =>
  res.status(501).json({ error: `${what} is not available. Transactions must be signed in a user-controlled wallet and no verified Rialo venue exists yet.` });
router.post('/swap', notAvailable('Swap execution'));
router.post('/sell', notAvailable('Selling'));
router.post('/send', notAvailable('Sending'));
router.post('/bridge', notAvailable('Bridging'));
export default router;
